import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

interface NewsArticle {
  id: string
  title: string
  excerpt: string
  content: string
  date: string
  author: string
  category: string
  image: string
  views: number
  featured?: boolean
}

export default function NewsPage() {
  // News articles data
  const newsArticles = [
    {
      id: "fort-hill-clinches-title",
      title: "Fort Hill clinches conference title with win over Allegany",
      excerpt:
        "The Sentinels secured their third straight WMAC title with a thrilling 72-68 victory over rival Allegany.",
      content:
        "In a packed gymnasium, Fort Hill's Marcus Johnson led all scorers with 24 points as the Sentinels held off a late rally from the Campers. The win gives Fort Hill the top seed in the upcoming playoffs.",
      date: "March 5, 2025",
      author: "Mike Stevens",
      category: "Game Recap",
      image: "/placeholder.svg?height=400&width=600&text=Fort+Hill+vs+Allegany",
      views: 1245,
      featured: true,
    },
    {
      id: "manhertz-player-of-week",
      title: "Chris Manhertz named Player of the Week",
      excerpt: "Allegany's star point guard earns the honor after averaging 28.5 points in two crucial victories.",
      content:
        "Chris Manhertz continued his stellar senior season with back-to-back 25+ point performances, including a 32-point outburst against Mountain Ridge. The Campers' floor general also dished out 8 assists per game during the stretch.",
      date: "March 3, 2025",
      author: "Sarah Johnson",
      category: "Awards",
      image: "/placeholder.svg?height=400&width=600&text=Chris+Manhertz",
      views: 982,
      featured: true,
    },
    {
      id: "mountain-ridge-upset",
      title: "Mountain Ridge upsets Southern Garrett in overtime thriller",
      excerpt: "The Miners rallied from a 15-point deficit to stun the Rams 85-82 in an extra period classic.",
      content:
        "Jamal Thompson's three-pointer with 5 seconds remaining in overtime capped a remarkable comeback for Mountain Ridge. The junior guard finished with 27 points, while Darius Williams added 22 points and 14 rebounds.",
      date: "February 28, 2025",
      author: "Tom Wilson",
      category: "Game Recap",
      image: "/placeholder.svg?height=400&width=600&text=Mountain+Ridge+vs+Southern+Garrett",
      views: 876,
      featured: true,
    },
    {
      id: "playoff-picture",
      title: "WMAC Playoff Picture: Breaking down the seeding scenarios",
      excerpt: "With one week left in the regular season, we analyze the potential playoff matchups.",
      content:
        "Fort Hill has secured the top seed, but positions 2-4 remain up for grabs. We break down the remaining schedules and tiebreaker scenarios as teams make their final push for playoff positioning.",
      date: "February 25, 2025",
      author: "Mike Stevens",
      category: "Analysis",
      image: "/placeholder.svg?height=400&width=600&text=Playoff+Picture",
      views: 1102,
    },
    {
      id: "northern-garrett-streak",
      title: "Northern Garrett snaps three-game losing streak",
      excerpt: "The Huskies got back in the win column with a convincing 65-52 victory over Bishop Walsh.",
      content:
        "Michael Carter dominated inside with 18 points and 15 rebounds as Northern Garrett controlled the paint from start to finish. The win keeps the Huskies' playoff hopes alive heading into the final week of the regular season.",
      date: "February 22, 2025",
      author: "Sarah Johnson",
      category: "Game Recap",
      image: "/placeholder.svg?height=400&width=600&text=Northern+Garrett+vs+Bishop+Walsh",
      views: 743,
    },
    {
      id: "coach-interview",
      title: "Coach's Corner: One-on-one with Fort Hill's Todd Eirich",
      excerpt: "We sit down with the Sentinels' veteran coach to discuss their championship season.",
      content:
        "Todd Eirich shares insights on his team's development, key players stepping up, and their approach to the upcoming playoffs as they seek their third consecutive WMAC championship.",
      date: "February 20, 2025",
      author: "Tom Wilson",
      category: "Interview",
      image: "/placeholder.svg?height=400&width=600&text=Coach+Todd+Eirich",
      views: 865,
    },
    {
      id: "allegany-win-streak",
      title: "Allegany extends win streak to six games",
      excerpt: "The Campers continue their late-season surge with a dominant win over Bishop Walsh.",
      content:
        "Chris Manhertz and Tyrell Washington combined for 45 points as Allegany cruised to an 82-65 victory. The Campers have not lost since January 28 and are peaking at the right time.",
      date: "February 18, 2025",
      author: "Mike Stevens",
      category: "Game Recap",
      image: "/placeholder.svg?height=400&width=600&text=Allegany+Win+Streak",
      views: 792,
    },
    {
      id: "southern-garrett-injury",
      title: "Southern Garrett's Brandon Miller returns from injury",
      excerpt: "The Rams' star forward made his comeback after missing three weeks with an ankle sprain.",
      content:
        "Brandon Miller scored 15 points in limited minutes as he eased back into action. The senior's return provides a significant boost to Southern Garrett's frontcourt as they prepare for the postseason.",
      date: "February 15, 2025",
      author: "Sarah Johnson",
      category: "Injury Update",
      image: "/placeholder.svg?height=400&width=600&text=Brandon+Miller+Return",
      views: 831,
    },
  ]

  const featuredArticles = newsArticles.filter((article) => article.featured)
  const recentArticles = newsArticles.filter((article) => !article.featured).slice(0, 5)

  const categories = Array.from(new Set(newsArticles.map((article) => article.category)))

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero section */}
      <div className="bg-[#0a2240] py-12">
        <div className="container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl font-bold mb-4">Basketball News</h1>
          <p className="text-xl max-w-2xl mx-auto">The latest updates from Western Maryland high school basketball</p>
        </div>
      </div>

      {/* News content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {newsArticles.map((article) => (
            <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48 w-full">
                <Image src={article.image || "/placeholder.svg"} alt={article.title} fill className="object-cover" />
              </div>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-lg hover:text-[#e31837] cursor-pointer">{article.title}</CardTitle>
                <div className="text-xs text-gray-500 flex justify-between">
                  <span>{article.date}</span>
                  <span>By {article.author}</span>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-2">
                <p className="text-sm text-gray-700 mb-4">{article.excerpt}</p>
                <Link href={`/news/${article.id}`} className="text-[#e31837] text-sm font-semibold hover:underline">
                  Read More →
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

