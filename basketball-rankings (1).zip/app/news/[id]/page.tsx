import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"

interface NewsArticle {
  id: string
  title: string
  excerpt: string
  content: string
  date: string
  author: string
  category: string
  image: string
  views: number
  featured?: boolean
}

// This would typically come from a database or API
const getArticle = (id: string) => {
  const articles = [
    {
      id: "1",
      title: "Fort Hill clinches conference title with win over Allegany",
      date: "March 5, 2025",
      content: `
        <p>In a thrilling matchup that lived up to the hype, Fort Hill secured the conference title with a hard-fought 72-68 victory over rival Allegany on Wednesday night. The Sentinels' senior guard Jaden Yates led all scorers with 22 points, including four crucial free throws in the final minute to seal the win.</p>
        
        <p>The game was a back-and-forth affair throughout, with neither team able to build a lead larger than six points. Allegany's Chris Manhertz kept the Campers in the game with 20 points and 8 rebounds, but it wasn't enough to overcome Fort Hill's balanced attack.</p>
        
        <p>"This is what we've been working for all season," said Fort Hill coach John Davis. "These kids have put in the work, and they deserve this moment. Allegany is a great team, and we knew it would be a battle until the final buzzer."</p>
        
        <p>With the win, Fort Hill improves to 18-3 overall and 10-0 in conference play, clinching the regular season title with two games remaining. Allegany falls to 16-5 overall and 8-2 in the conference.</p>
        
        <p>In addition to Yates' 22 points, Fort Hill got 15 points from Tavin Willis and 12 points and 9 rebounds from Deshaun Brown. For Allegany, Tyrell Washington added 16 points and 6 assists to complement Manhertz's performance.</p>
        
        <p>Both teams will now turn their attention to the upcoming playoffs, where they could potentially meet again in the regional final.</p>
      `,
      image: "/placeholder.svg?height=400&width=800",
      author: "John Smith",
    },
    {
      id: "2",
      title: "Chris Manhertz named Player of the Week",
      date: "March 3, 2025",
      content: `
        <p>Allegany's Chris Manhertz has been named Western Maryland Athletic Conference Player of the Week after averaging 28.5 points and 10.2 rebounds in two key victories for the Campers.</p>
        
        <p>The senior guard scored 32 points in a win over Bishop Walsh on Tuesday, then followed it up with 25 points and 12 rebounds in a crucial conference victory against Northern Garrett on Friday.</p>
        
        <p>"Chris has been our leader all season, both on and off the court," said Allegany coach Mike Johnson. "He's playing at an incredibly high level right now, and his performance this week was exceptional even by his standards."</p>
        
        <p>Manhertz, who is averaging 24.5 points per game this season, has scored 20 or more points in nine consecutive games. He is currently being recruited by several Division II colleges and has received interest from a few mid-major Division I programs.</p>
        
        <p>"I'm just trying to help my team win games," Manhertz said when asked about the honor. "My teammates are putting me in great positions to score, and I'm just trying to make the most of those opportunities."</p>
        
        <p>Allegany is currently 16-4 overall and 8-1 in conference play, with a showdown against undefeated Fort Hill looming this Wednesday.</p>
      `,
      image: "/placeholder.svg?height=400&width=800",
      author: "Sarah Johnson",
    },
    // Add more articles as needed
  ]

  return articles.find((article) => article.id === id) || null
}

// Add the default export function for the page component
export default function NewsArticlePage({ params }: { params: { id: string } }) {
  const article = getArticle(params.id)

  if (!article) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Article Not Found</h1>
        <p>The article you're looking for doesn't exist or has been removed.</p>
        <Link href="/news" className="text-[#e31837] font-semibold hover:underline mt-4 inline-block">
          <ArrowLeft className="h-4 w-4 inline mr-2" />
          Back to News
        </Link>
      </div>
    )
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero section */}
      <div className="bg-[#0a2240] py-8">
        <div className="container mx-auto px-4 text-white">
          <Link href="/news" className="text-white hover:text-gray-200 inline-flex items-center mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to News
          </Link>
          <h1 className="text-3xl font-bold">{article.title}</h1>
          <div className="flex items-center mt-2 text-sm">
            <span>{article.date}</span>
            <span className="mx-2">•</span>
            <span>By {article.author}</span>
          </div>
        </div>
      </div>

      {/* Article content */}
      <div className="container mx-auto px-4 py-8">
        <Card className="overflow-hidden">
          <div className="relative h-64 md:h-96 w-full">
            <Image src={article.image || "/placeholder.svg"} alt={article.title} fill className="object-cover" />
          </div>
          <CardContent className="p-6 md:p-8">
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: article.content }} />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

