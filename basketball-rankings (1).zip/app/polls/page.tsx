import { Poll } from "@/components/poll"
import Image from "next/image"

export default function PollsPage() {
  // Player of the Week poll options
  const playerOfWeekOptions = [
    {
      id: "chris-manhertz",
      name: "Chris Manhertz",
      teamName: "Allegany",
      position: "PG",
      grade: "Senior",
      votes: 24,
    },
    {
      id: "marcus-johnson",
      name: "Marcus Johnson",
      teamName: "Fort Hill",
      position: "SG",
      grade: "Senior",
      votes: 18,
    },
    {
      id: "cameron-breighner",
      name: "Cameron Breighner",
      teamName: "Mountain Ridge",
      position: "PF",
      grade: "Junior",
      votes: 12,
    },
    {
      id: "brandon-miller",
      name: "Brandon Miller",
      teamName: "Southern Garrett",
      position: "SF",
      grade: "Senior",
      votes: 9,
    },
  ]

  // Coach of the Year poll options
  const coachOfYearOptions = [
    {
      id: "todd-eirich",
      name: "Todd Eirich",
      teamName: "Fort Hill",
      votes: 16,
    },
    {
      id: "tedd-eirich",
      name: "Tedd Eirich",
      teamName: "Allegany",
      votes: 14,
    },
    {
      id: "tom-bosley",
      name: "Tom Bosley",
      teamName: "Southern Garrett",
      votes: 11,
    },
    {
      id: "dave-hobel",
      name: "Dave Hobel",
      teamName: "Mountain Ridge",
      votes: 8,
    },
  ]

  // Most Improved Player poll options
  const mostImprovedOptions = [
    {
      id: "will-metz",
      name: "Will Metz",
      teamName: "Mountain Ridge",
      position: "G",
      grade: "Senior",
      votes: 15,
    },
    {
      id: "tyrell-washington",
      name: "Tyrell Washington",
      teamName: "Allegany",
      position: "PG",
      grade: "Junior",
      votes: 13,
    },
    {
      id: "ethan-nguyen",
      name: "Ethan Nguyen",
      teamName: "Fort Hill",
      position: "F",
      grade: "Sophomore",
      votes: 9,
    },
    {
      id: "noah-clark",
      name: "Noah Clark",
      teamName: "Southern Garrett",
      position: "F",
      grade: "Sophomore",
      votes: 7,
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center gap-4">
        <div className="relative w-16 h-16">
          <Image
            src="/images/wmsn-logo.png"
            alt="Western Maryland Sports Network Logo"
            fill
            sizes="64px"
            className="object-contain"
            style={{ background: "transparent" }}
            priority
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold mb-2">Fan Polls</h1>
          <p className="text-gray-500">Vote for your favorite players and coaches</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Poll
          id="player-of-week"
          title="Player of the Week"
          description="Vote for the top performer from last week's games"
          options={playerOfWeekOptions}
          endDate="March 27, 2025"
        />

        <Poll
          id="coach-of-year"
          title="Coach of the Year"
          description="Who deserves the Coach of the Year award for the 2024-2025 season?"
          options={coachOfYearOptions}
          endDate="April 15, 2025"
        />

        <Poll
          id="most-improved"
          title="Most Improved Player"
          description="Which player has shown the most improvement this season?"
          options={mostImprovedOptions}
          endDate="April 10, 2025"
        />
      </div>

      <div className="mt-8 p-6 bg-gray-50 rounded-lg border">
        <h2 className="text-xl font-bold mb-4">About Fan Polls</h2>
        <div className="space-y-4 text-sm">
          <p>
            Welcome to WMAC Hoops Fan Polls! This is your chance to have your voice heard and support your favorite
            players and coaches from across the Western Maryland Athletic Conference.
          </p>
          <p>
            New polls are posted weekly during the season. The results are for entertainment purposes and don't impact
            official awards, but they do represent the voice of the fans!
          </p>
          <p>
            <strong>Have a poll suggestion?</strong> Send us your ideas for future poll categories on our social media
            channels.
          </p>
        </div>
      </div>
    </div>
  )
}

