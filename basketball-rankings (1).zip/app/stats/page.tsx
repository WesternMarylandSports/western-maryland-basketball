import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function StatsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Statistics</h1>
        <p className="text-gray-500">Team and player statistics for the 2024-2025 season</p>
      </div>

      <Tabs defaultValue="team" className="w-full">
        <div className="bg-[#0a2240] p-1 rounded-t-md">
          <TabsList className="grid w-full grid-cols-2 bg-transparent gap-1">
            <TabsTrigger
              value="team"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Team Statistics
            </TabsTrigger>
            <TabsTrigger
              value="player"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Player Statistics
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="bg-white rounded-b-md border border-t-0 p-6">
          <TabsContent value="team" className="m-0">
            <Card>
              <CardHeader className="bg-[#0a2240] text-white">
                <CardTitle className="text-lg">Team Offensive Statistics</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-[#f8f9fa]">
                    <TableRow>
                      <TableHead className="font-bold">Team</TableHead>
                      <TableHead className="text-center font-bold">PPG</TableHead>
                      <TableHead className="text-center font-bold">FG%</TableHead>
                      <TableHead className="text-center font-bold">3P%</TableHead>
                      <TableHead className="text-center font-bold">FT%</TableHead>
                      <TableHead className="text-center font-bold">AST</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Fort Hill</TableCell>
                      <TableCell className="text-center">78.5</TableCell>
                      <TableCell className="text-center">47.0%</TableCell>
                      <TableCell className="text-center">38.0%</TableCell>
                      <TableCell className="text-center">76.0%</TableCell>
                      <TableCell className="text-center">18.7</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Allegany</TableCell>
                      <TableCell className="text-center">72.3</TableCell>
                      <TableCell className="text-center">45.0%</TableCell>
                      <TableCell className="text-center">36.0%</TableCell>
                      <TableCell className="text-center">72.0%</TableCell>
                      <TableCell className="text-center">16.9</TableCell>
                    </TableRow>
                    {/* Add more rows as needed */}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="player" className="m-0">
            <Card>
              <CardHeader className="bg-[#0a2240] text-white">
                <CardTitle className="text-lg">Individual Player Statistics</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-[#f8f9fa]">
                    <TableRow>
                      <TableHead className="font-bold">Player</TableHead>
                      <TableHead className="text-center font-bold">PPG</TableHead>
                      <TableHead className="text-center font-bold">RPG</TableHead>
                      <TableHead className="text-center font-bold">APG</TableHead>
                      <TableHead className="text-center font-bold">SPG</TableHead>
                      <TableHead className="text-center font-bold">BPG</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Chris Manhertz</TableCell>
                      <TableCell className="text-center">24.5</TableCell>
                      <TableCell className="text-center">4.2</TableCell>
                      <TableCell className="text-center">5.8</TableCell>
                      <TableCell className="text-center">2.3</TableCell>
                      <TableCell className="text-center">0.4</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Tyrell Washington</TableCell>
                      <TableCell className="text-center">22.3</TableCell>
                      <TableCell className="text-center">3.5</TableCell>
                      <TableCell className="text-center">6.7</TableCell>
                      <TableCell className="text-center">2.4</TableCell>
                      <TableCell className="text-center">0.2</TableCell>
                    </TableRow>
                    {/* Add more rows as needed */}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

