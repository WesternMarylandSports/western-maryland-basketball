import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { teamsData } from "@/data/teams-data"
import Link from "next/link"

export default function TeamsPage() {
  // Get team color for the avatar
  const getTeamColor = (teamName: string) => {
    switch (teamName) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Teams</h1>
        <p className="text-gray-500">Team information and rosters for the 2024-2025 season</p>
      </div>

      {/* Team Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {teamsData.map((team) => (
          <Link key={team.name} href={`/teams#${team.name.toLowerCase().replace(/\s+/g, "-")}`} className="block">
            <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
              <div className={`${getTeamColor(team.name)} h-3`} />
              <CardHeader className="pb-2">
                <CardTitle className="flex justify-between items-center">
                  <span>
                    {team.name} {team.mascot}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4">
                  <div
                    className={`w-16 h-16 rounded-full ${getTeamColor(team.name)} text-white flex items-center justify-center font-bold text-xl`}
                  >
                    {team.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Colors</div>
                    <div className="flex gap-2 mt-1">
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: team.colors.primary }} />
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: team.colors.secondary }} />
                    </div>
                  </div>
                </div>

                <div className="text-sm">
                  <div className="font-medium mb-1">Roster Size: {team.players.length} players</div>
                  <div className="text-gray-500">
                    {team.players.filter((p) => p.grade === "Sr").length} Seniors,{" "}
                    {team.players.filter((p) => p.grade === "Jr").length} Juniors,{" "}
                    {team.players.filter((p) => p.grade === "So").length} Sophomores,{" "}
                    {team.players.filter((p) => p.grade === "Fr").length} Freshmen
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Team Rosters */}
      <div className="space-y-10">
        {teamsData.map((team) => (
          <div key={team.name} id={team.name.toLowerCase().replace(/\s+/g, "-")} className="scroll-mt-20">
            <Card>
              <CardHeader className={getTeamColor(team.name) + " text-white"}>
                <CardTitle className="flex justify-between items-center">
                  <span>
                    {team.name} {team.mascot}
                  </span>
                  <span className="text-sm">
                    Colors: Primary - {team.colors.primary}, Secondary - {team.colors.secondary}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="text-left p-2 border">#</th>
                        <th className="text-left p-2 border">Name</th>
                        <th className="text-left p-2 border">Position</th>
                        <th className="text-left p-2 border">Height</th>
                        <th className="text-left p-2 border">Grade</th>
                      </tr>
                    </thead>
                    <tbody>
                      {team.players.map((player, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="p-2 border">{player.number}</td>
                          <td className="p-2 border">
                            <Link
                              href={`/players/${player.name.toLowerCase().replace(/\s+/g, "-")}`}
                              className="hover:text-[#e31837] font-medium"
                            >
                              {player.name}
                            </Link>
                          </td>
                          <td className="p-2 border">{player.position}</td>
                          <td className="p-2 border">{player.height}</td>
                          <td className="p-2 border">{player.grade}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </div>
  )
}

