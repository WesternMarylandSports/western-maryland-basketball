import { MediaUpload } from "@/components/media-upload"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

export default function MediaPage() {
  // Sample media items for the gallery
  const sampleMedia = [
    {
      id: "1",
      type: "photo",
      title: "Fort Hill vs Allegany Game",
      team: "Fort Hill",
      date: "March 5, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Game+Photo+1",
    },
    {
      id: "2",
      type: "photo",
      title: "Mountain Ridge Team Photo",
      team: "Mountain Ridge",
      date: "February 15, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Team+Photo",
    },
    {
      id: "3",
      type: "video",
      title: "Chris Manhertz Highlights",
      player: "Chris Manhertz",
      team: "Allegany",
      date: "March 10, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Highlight+Video",
    },
    {
      id: "4",
      type: "photo",
      title: "Southern Garrett vs Northern Garrett",
      team: "Southern Garrett",
      date: "February 28, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Game+Photo+2",
    },
    {
      id: "5",
      type: "video",
      title: "Brandon Miller Dunk Compilation",
      player: "Brandon Miller",
      team: "Southern Garrett",
      date: "March 8, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Dunk+Compilation",
    },
    {
      id: "6",
      type: "photo",
      title: "Bishop Walsh Senior Night",
      team: "Bishop Walsh",
      date: "February 20, 2025",
      image: "/placeholder.svg?height=200&width=400&text=Senior+Night",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Media Gallery</h1>
        <p className="text-gray-500">Upload and browse photos, videos, and highlights</p>
      </div>

      <Tabs defaultValue="gallery" className="space-y-6">
        <TabsList>
          <TabsTrigger value="gallery">Media Gallery</TabsTrigger>
          <TabsTrigger value="upload">Upload Media</TabsTrigger>
        </TabsList>

        <TabsContent value="gallery" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sampleMedia.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                  {item.type === "video" && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-black/50 flex items-center justify-center">
                        <div className="w-0 h-0 border-t-8 border-t-transparent border-l-16 border-l-white border-b-8 border-b-transparent ml-1"></div>
                      </div>
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg mb-1">{item.title}</h3>
                  <div className="text-sm text-gray-500 flex flex-wrap gap-x-2">
                    <span>{item.team}</span>
                    {item.player && (
                      <>
                        <span>•</span>
                        <span>{item.player}</span>
                      </>
                    )}
                  </div>
                  <div className="text-xs text-gray-400 mt-2">{item.date}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Team Galleries</CardTitle>
              <CardDescription>Browse media by team</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  "Fort Hill",
                  "Allegany",
                  "Southern Garrett",
                  "Mountain Ridge",
                  "Northern Garrett",
                  "Bishop Walsh",
                ].map((team) => (
                  <Link key={team} href={`/media/teams/${team.toLowerCase().replace(/\s+/g, "-")}`} className="block">
                    <div className="aspect-square bg-gray-100 rounded-md flex items-center justify-center p-4 hover:bg-gray-200 transition-colors">
                      <div className="text-center">
                        <div className="font-bold text-sm">{team}</div>
                        <div className="text-xs text-gray-500 mt-1">Gallery</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload">
          <MediaUpload />
        </TabsContent>
      </Tabs>
    </div>
  )
}

