import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PhotosPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Photos</h1>
        <p className="text-gray-500">Game photos and team galleries for the 2024-2025 season</p>
      </div>

      <Tabs defaultValue="recent" className="w-full">
        <div className="bg-[#0a2240] p-1 rounded-t-md">
          <TabsList className="grid w-full grid-cols-3 bg-transparent gap-1">
            <TabsTrigger
              value="recent"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Recent Photos
            </TabsTrigger>
            <TabsTrigger
              value="teams"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Team Galleries
            </TabsTrigger>
            <TabsTrigger
              value="games"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Game Galleries
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="bg-white rounded-b-md border border-t-0 p-6">
          <TabsContent value="recent" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative aspect-video bg-gray-200">
                      <img
                        src={`/placeholder.svg?height=200&width=400&text=Game+Photo+${i}`}
                        alt={`Basketball game photo ${i}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-3">
                      <h3 className="font-medium">Fort Hill vs Allegany Game</h3>
                      <p className="text-xs text-gray-500">March 5, 2025</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="teams" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {["Fort Hill", "Allegany", "Southern Garrett", "Mountain Ridge", "Northern Garrett", "Bishop Walsh"].map(
                (team) => (
                  <Card key={team} className="overflow-hidden">
                    <CardContent className="p-0">
                      <div className="relative aspect-video bg-gray-200">
                        <img
                          src={`/placeholder.svg?height=200&width=400&text=${team}`}
                          alt={`${team} team photo`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-3">
                        <h3 className="font-medium">{team} Sentinels</h3>
                        <p className="text-xs text-gray-500">Team Gallery</p>
                      </div>
                    </CardContent>
                  </Card>
                ),
              )}
            </div>
          </TabsContent>

          <TabsContent value="games" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                "Fort Hill vs Allegany",
                "Southern Garrett vs Mountain Ridge",
                "Bishop Walsh vs Northern Garrett",
                "Allegany vs Mountain Ridge",
                "Northern Garrett vs Fort Hill",
                "Mountain Ridge vs Bishop Walsh",
              ].map((game) => (
                <Card key={game} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative aspect-video bg-gray-200">
                      <img
                        src={`/placeholder.svg?height=200&width=400&text=${game.replace(/ /g, "+")}`}
                        alt={`${game} game photos`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-3">
                      <h3 className="font-medium">{game}</h3>
                      <p className="text-xs text-gray-500">Game Gallery</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

