"use client"

import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Link from "next/link"
import Image from "next/image"
import { SearchBar } from "@/components/search-bar"
import { MobileSearch } from "@/components/mobile-search"
import { MobileNav } from "@/components/mobile-nav"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <title>Western Maryland Basketball</title>
        <meta name="description" content="High school basketball coverage for Western Maryland" />
        <meta name="theme-color" content="#0a2240" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="WMAC Hoops" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <script src="/pwa.js" defer></script>
      </head>
      <body className={`${inter.className} bg-gray-50 min-h-screen`}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <header className="bg-[#0a2240] text-white">
            <div className="container mx-auto py-3 px-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-3">
                  <Link href="/" className="flex items-center gap-3">
                    <div className="relative w-12 h-12">
                      <Image
                        src="/images/wmsn-logo.png"
                        alt="Western Maryland Sports Network Logo"
                        fill
                        sizes="48px"
                        className="object-contain"
                        style={{ background: "transparent" }}
                        priority
                      />
                    </div>
                    <span className="font-bold text-2xl tracking-tight">WMAC HOOPS</span>
                  </Link>
                  <span className="text-xs bg-[#e31837] px-2 py-0.5 rounded">OFFICIAL</span>
                </div>
                <div className="hidden md:flex space-x-6 text-sm">
                  <Link
                    href="/"
                    className={cn("hover:text-gray-300", pathname === "/" && "text-[#e31837] font-semibold")}
                  >
                    HOME
                  </Link>
                  <Link
                    href="/teams"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/teams") && "text-[#e31837] font-semibold",
                    )}
                  >
                    TEAMS
                  </Link>
                  <Link
                    href="/players"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/players") && "text-[#e31837] font-semibold",
                    )}
                  >
                    PLAYERS
                  </Link>
                  <Link
                    href="/schedules"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/schedules") && "text-[#e31837] font-semibold",
                    )}
                  >
                    SCHEDULES
                  </Link>
                  <Link
                    href="/standings"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/standings") && "text-[#e31837] font-semibold",
                    )}
                  >
                    STANDINGS
                  </Link>
                  <Link
                    href="/stats"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/stats") && "text-[#e31837] font-semibold",
                    )}
                  >
                    STATS
                  </Link>
                  <Link
                    href="/photos"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/photos") && "text-[#e31837] font-semibold",
                    )}
                  >
                    PHOTOS
                  </Link>
                  <Link
                    href="/media"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/media") && "text-[#e31837] font-semibold",
                    )}
                  >
                    MEDIA
                  </Link>
                  <Link
                    href="/news"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/news") && "text-[#e31837] font-semibold",
                    )}
                  >
                    NEWS
                  </Link>
                  <Link
                    href="/polls"
                    className={cn(
                      "hover:text-gray-300",
                      pathname.startsWith("/polls") && "text-[#e31837] font-semibold",
                    )}
                  >
                    POLLS
                  </Link>
                </div>
                <div className="hidden md:block w-64 ml-4">
                  <SearchBar />
                </div>
                <div className="md:hidden flex items-center">
                  <MobileSearch />
                  <MobileNav />
                </div>
              </div>
            </div>
            <div className="bg-[#e31837] py-1">
              <div className="container mx-auto px-4">
                <div className="text-xs font-medium">2024-2025 BASKETBALL SEASON</div>
              </div>
            </div>
          </header>
          <main>{children}</main>
          <footer className="bg-[#0a2240] text-white py-8 mt-12">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="relative w-10 h-10">
                      <Image
                        src="/images/wmsn-logo.png"
                        alt="Western Maryland Sports Network Logo"
                        fill
                        sizes="40px"
                        className="object-contain"
                        style={{ background: "transparent" }}
                      />
                    </div>
                    <h3 className="font-bold text-lg">WMAC HOOPS</h3>
                  </div>
                  <p className="text-sm text-gray-300">
                    The official source for Western Maryland high school basketball scores, stats, rankings, and more.
                  </p>
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-4">QUICK LINKS</h3>
                  <ul className="text-sm space-y-2 text-gray-300">
                    <li>
                      <Link href="/teams" className="hover:text-white">
                        Teams
                      </Link>
                    </li>
                    <li>
                      <Link href="/players" className="hover:text-white">
                        Players
                      </Link>
                    </li>
                    <li>
                      <Link href="/schedules" className="hover:text-white">
                        Schedules
                      </Link>
                    </li>
                    <li>
                      <Link href="/standings" className="hover:text-white">
                        Standings
                      </Link>
                    </li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-4">FOLLOW US</h3>
                  <div className="flex space-x-4 text-sm text-gray-300">
                    <a href="#" className="hover:text-white">
                      Twitter
                    </a>
                    <a href="#" className="hover:text-white">
                      Facebook
                    </a>
                    <a
                      href="https://www.instagram.com/westernmarylandsportsnetwork?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
                      className="hover:text-white"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Instagram
                    </a>
                  </div>
                </div>
              </div>
              <div className="mt-8 pt-8 border-t border-gray-700 text-sm text-gray-400 text-center">
                © 2025 Western Maryland Athletic Conference. All rights reserved.
              </div>
            </div>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  )
}

