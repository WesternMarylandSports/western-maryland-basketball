import BasketballRankings from "@/basketball-rankings"
import Image from "next/image"

export default function StandingsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center gap-4">
        <div className="relative w-16 h-16">
          <Image
            src="/images/wmsn-logo.png"
            alt="Western Maryland Sports Network Logo"
            fill
            sizes="64px"
            className="object-contain"
            style={{ background: "transparent" }}
            priority
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Standings</h1>
          <p className="text-gray-500">Complete standings for the 2024-2025 season</p>
        </div>
      </div>

      <BasketballRankings />

      <div className="mt-12 bg-gray-50 p-6 rounded-lg border">
        <h2 className="text-xl font-bold mb-4">Standings Explained</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold">Conference Standings</h3>
            <p className="text-sm text-gray-600">
              Teams are ranked based on their conference record. In case of a tie, the following tiebreakers are used:
              head-to-head record, points differential, and total points scored.
            </p>
          </div>

          <div>
            <h3 className="font-semibold">Playoff Qualification</h3>
            <p className="text-sm text-gray-600">
              The top 4 teams in the WMAC conference qualify for the playoffs. The #1 seed plays the #4 seed, and the #2
              seed plays the #3 seed in the semifinals.
            </p>
          </div>

          <div>
            <h3 className="font-semibold">Last Updated</h3>
            <p className="text-sm text-gray-600">Standings are updated daily. Last update: March 20, 2025.</p>
          </div>
        </div>
      </div>
    </div>
  )
}

