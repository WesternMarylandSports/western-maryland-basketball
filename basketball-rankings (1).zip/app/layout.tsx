import type React from "react"
import ClientLayout from "./ClientLayout"
import "./globals.css"

export const metadata = {
  title: "WMAC Hoops",
  description: "Western Maryland High School Basketball",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <ClientLayout>{children}</ClientLayout>
}

