"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { SearchBar } from "@/components/search-bar"
import Link from "next/link"
import Image from "next/image"

interface SearchResult {
  id: string
  name: string
  type: "player" | "team"
  subtitle?: string
  details?: string
  image?: string
  url: string
}

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Sample data for search results
  const searchData: SearchResult[] = [
    // Teams
    {
      id: "fort-hill",
      name: "Fort Hill",
      type: "team",
      subtitle: "Sentinels",
      details: "Record: 15-10 (10-2 WMAC) • Coach: Todd Eirich",
      url: "/teams#fort-hill",
    },
    {
      id: "allegany",
      name: "Allegany",
      type: "team",
      subtitle: "Campers",
      details: "Record: 11-13 (7-5 WMAC) • Coach: Tedd Eirich",
      url: "/teams#allegany",
    },
    {
      id: "southern-garrett",
      name: "Southern Garrett",
      type: "team",
      subtitle: "Rams",
      details: "Record: 13-11 (8-4 WMAC) • Coach: Tom Bosley",
      url: "/teams#southern-garrett",
    },
    {
      id: "mountain-ridge",
      name: "Mountain Ridge",
      type: "team",
      subtitle: "Miners",
      details: "Record: 14-6 (7-5 WMAC) • Coach: Dave Hobel",
      url: "/teams#mountain-ridge",
    },
    {
      id: "northern-garrett",
      name: "Northern Garrett",
      type: "team",
      subtitle: "Huskies",
      details: "Record: 10-13 (5-7 WMAC) • Coach: Tim Preston",
      url: "/teams#northern-garrett",
    },
    {
      id: "bishop-walsh",
      name: "Bishop Walsh",
      type: "team",
      subtitle: "Spartans",
      details: "Record: 6-19 (2-10 WMAC) • Coach: Dan Prete",
      url: "/teams#bishop-walsh",
    },

    // Players
    {
      id: "chris-manhertz",
      name: "Chris Manhertz",
      type: "player",
      subtitle: "Allegany • PG • Junior",
      details: "24.5 PPG • 4.2 RPG • 5.8 APG",
      url: "/players#chris-manhertz",
    },
    {
      id: "tyrell-washington",
      name: "Tyrell Washington",
      type: "player",
      subtitle: "Allegany • PG • Junior",
      details: "22.3 PPG • 3.5 RPG • 6.7 APG",
      url: "/players#tyrell-washington",
    },
    {
      id: "brandon-miller",
      name: "Brandon Miller",
      type: "player",
      subtitle: "Southern Garrett • SF • Senior",
      details: "21.8 PPG • 7.3 RPG • 2.5 APG",
      url: "/players#brandon-miller",
    },
    {
      id: "jamal-thompson",
      name: "Jamal Thompson",
      type: "player",
      subtitle: "Mountain Ridge • SG • Senior",
      details: "20.5 PPG • 4.1 RPG • 3.2 APG",
      url: "/players#jamal-thompson",
    },
    {
      id: "darius-williams",
      name: "Darius Williams",
      type: "player",
      subtitle: "Bishop Walsh • PF • Junior",
      details: "19.8 PPG • 9.2 RPG • 1.5 APG",
      url: "/players#darius-williams",
    },
    {
      id: "michael-carter",
      name: "Michael Carter",
      type: "player",
      subtitle: "Northern Garrett • C • Senior",
      details: "18.6 PPG • 10.5 RPG • 1.2 APG",
      url: "/players#michael-carter",
    },
    {
      id: "marcus-johnson",
      name: "Marcus Johnson",
      type: "player",
      subtitle: "Fort Hill • SG • Senior",
      details: "24.0 PPG • 4.3 RPG • 3.8 APG",
      url: "/players#marcus-johnson",
    },
  ]

  useEffect(() => {
    if (query) {
      setIsLoading(true)
      // Simulate API call with setTimeout
      setTimeout(() => {
        const filtered = searchData.filter(
          (item) =>
            item.name.toLowerCase().includes(query.toLowerCase()) ||
            (item.subtitle && item.subtitle.toLowerCase().includes(query.toLowerCase())) ||
            (item.details && item.details.toLowerCase().includes(query.toLowerCase())),
        )
        setResults(filtered)
        setIsLoading(false)
      }, 500)
    } else {
      setResults([])
      setIsLoading(false)
    }
  }, [query])

  // Get team color for avatar
  const getTeamColor = (team: string) => {
    switch (team) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  const teamResults = results.filter((r) => r.type === "team")
  const playerResults = results.filter((r) => r.type === "player")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex items-center gap-4">
        <div className="relative w-16 h-16">
          <Image
            src="/images/wmsn-logo.png"
            alt="Western Maryland Sports Network Logo"
            fill
            sizes="64px"
            className="object-contain"
            style={{ background: "transparent" }}
            priority
          />
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold mb-2">Search Results</h1>
          <p className="text-gray-500">
            {query ? `Showing results for "${query}"` : "Enter a search term to find players and teams"}
          </p>
        </div>
      </div>

      <div className="mb-8 max-w-2xl">
        <SearchBar />
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#0a2240] border-r-transparent"></div>
          <p className="mt-4 text-gray-500">Searching...</p>
        </div>
      ) : (
        <>
          {query && results.length === 0 ? (
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold mb-2">No results found</h2>
              <p className="text-gray-500">
                We couldn't find any matches for "{query}". Please try another search term.
              </p>
            </div>
          ) : (
            <div>
              {query && (
                <div className="mb-6">
                  <p className="text-sm text-gray-500">
                    Found {results.length} results ({teamResults.length} teams, {playerResults.length} players)
                  </p>
                </div>
              )}

              <Tabs defaultValue="all" className="w-full">
                <div className="bg-[#0a2240] p-1 rounded-t-md">
                  <TabsList className="grid w-full grid-cols-3 bg-transparent gap-1">
                    <TabsTrigger
                      value="all"
                      className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                    >
                      All Results ({results.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="teams"
                      className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                    >
                      Teams ({teamResults.length})
                    </TabsTrigger>
                    <TabsTrigger
                      value="players"
                      className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                    >
                      Players ({playerResults.length})
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="bg-white border border-t-0 rounded-b-md p-6">
                  <TabsContent value="all" className="m-0 space-y-6">
                    {results.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {results.map((result) => (
                          <SearchResultCard key={result.id} result={result} getTeamColor={getTeamColor} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Enter a search term to see results</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="teams" className="m-0 space-y-6">
                    {teamResults.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {teamResults.map((result) => (
                          <SearchResultCard key={result.id} result={result} getTeamColor={getTeamColor} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No team results found</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="players" className="m-0 space-y-6">
                    {playerResults.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {playerResults.map((result) => (
                          <SearchResultCard key={result.id} result={result} getTeamColor={getTeamColor} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No player results found</p>
                      </div>
                    )}
                  </TabsContent>
                </div>
              </Tabs>
            </div>
          )}
        </>
      )}
    </div>
  )
}

interface SearchResultCardProps {
  result: SearchResult
  getTeamColor: (team: string) => string
}

function SearchResultCard({ result, getTeamColor }: SearchResultCardProps) {
  const teamName = result.type === "player" ? result.subtitle?.split("•")[0].trim() || "" : result.name

  return (
    <Link href={result.url}>
      <Card className="overflow-hidden h-full hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            {result.type === "team" ? (
              <div
                className={`w-12 h-12 rounded-full ${getTeamColor(result.name)} text-white flex items-center justify-center font-bold`}
              >
                {result.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </div>
            ) : (
              <Avatar className="h-12 w-12">
                <AvatarFallback className={`${getTeamColor(teamName)} text-white`}>
                  {result.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
            )}
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg">{result.name}</h3>
                <Badge variant="outline">{result.type === "team" ? "Team" : "Player"}</Badge>
              </div>
              <div className="text-sm text-gray-500">{result.subtitle}</div>
              <div className="text-sm mt-1">{result.details}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

