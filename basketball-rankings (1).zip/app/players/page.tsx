import PlayerRankings from "@/player-rankings"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { playersData } from "@/data/players-data"
import { UserRound } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { teamsData } from "@/data/teams-data"

export default function PlayersPage() {
  // Get featured players (the ones with detailed profiles)
  const featuredPlayers = playersData.filter(
    (player) =>
      player.highlights && player.highlights.length > 0 && player.achievements && player.achievements.length > 0,
  )

  // Get team color for the avatar
  const getTeamColor = (teamName: string) => {
    switch (teamName) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Players</h1>
        <p className="text-gray-500">Player rankings and statistics for the 2024-2025 season</p>
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Featured Player Profiles</h2>
          <Link href="/polls">
            <Button size="sm" variant="outline">
              Vote for Player of the Week
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {featuredPlayers.map((player) => (
            <Link key={player.id} href={`/players/${player.id}`} className="block group">
              <div className="bg-white rounded-lg shadow-md overflow-hidden border hover:shadow-lg transition-shadow">
                <div className="h-40 bg-gray-200 relative">
                  {player.image ? (
                    <img
                      src={player.image || "/placeholder.svg"}
                      alt={player.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-[#0a2240] text-white">
                      <UserRound className="h-16 w-16 opacity-30" />
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-bold group-hover:text-[#e31837] truncate">{player.name}</h3>
                  <div className="text-xs text-gray-500">
                    {player.team} • {player.position} • {player.grade}
                  </div>
                  <div className="mt-2 text-sm">
                    <span className="font-semibold">{player.stats.pointsPerGame.toFixed(1)}</span> PPG,
                    <span className="font-semibold"> {player.stats.reboundsPerGame.toFixed(1)}</span> RPG,
                    <span className="font-semibold"> {player.stats.assistsPerGame.toFixed(1)}</span> APG
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">All Players by Team</h2>

        <Tabs defaultValue={teamsData[0].name}>
          <TabsList className="flex flex-wrap">
            {teamsData.map((team) => (
              <TabsTrigger key={team.name} value={team.name} className="flex-shrink-0">
                {team.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {teamsData.map((team) => (
            <TabsContent key={team.name} value={team.name}>
              <div className="bg-white p-4 rounded-md border">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <div className={`w-6 h-6 rounded-full ${getTeamColor(team.name)}`}></div>
                  {team.name} {team.mascot} Roster
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {playersData
                    .filter((player) => player.team === team.name)
                    .sort((a, b) => {
                      // Sort by grade (Sr, Jr, So, Fr) then by name
                      const gradeOrder = { Sr: 0, Jr: 1, So: 2, Fr: 3 }
                      const gradeA = gradeOrder[a.grade as keyof typeof gradeOrder] || 4
                      const gradeB = gradeOrder[b.grade as keyof typeof gradeOrder] || 4

                      if (gradeA !== gradeB) return gradeA - gradeB
                      return a.name.localeCompare(b.name)
                    })
                    .map((player) => (
                      <Link
                        key={player.id}
                        href={`/players/${player.id}`}
                        className="flex items-center gap-3 p-3 rounded-md border hover:bg-gray-50 transition-colors"
                      >
                        <div
                          className={`w-10 h-10 rounded-full ${getTeamColor(team.name)} text-white flex items-center justify-center font-bold text-sm`}
                        >
                          {player.jerseyNumber}
                        </div>
                        <div>
                          <div className="font-medium">{player.name}</div>
                          <div className="text-xs text-gray-500">
                            {player.position} • {player.grade} • {player.height}
                          </div>
                        </div>
                      </Link>
                    ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      <PlayerRankings />
    </div>
  )
}

