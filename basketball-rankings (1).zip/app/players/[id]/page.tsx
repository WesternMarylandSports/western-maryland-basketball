import type React from "react"
import Image from "next/image"
import Link from "next/link"
import { getPlayerById, playersData } from "@/data/players-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Award, BarChart3, CalendarDays, MapPin, Ruler, Trophy, UserRound } from "lucide-react"
import { notFound } from "next/navigation"
import { PlayerMedia } from "@/components/player-media"

export default function PlayerProfilePage({ params }: { params: { id: string } }) {
  // Try to get player by exact ID match
  let player = getPlayerById(params.id)

  // If not found, try to find a player with a similar ID (for compatibility with links from team page)
  if (!player) {
    // Convert dashes to spaces and try to match by name
    const nameFromId = params.id.replace(/-/g, " ")
    player = playersData.find((p) => p.name.toLowerCase() === nameFromId.toLowerCase() || p.id.includes(params.id))
  }

  if (!player) {
    return notFound()
  }

  const getTeamColor = (team: string) => {
    switch (team) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/players" className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 mb-6">
        <ArrowLeft className="h-4 w-4" />
        <span>Back to All Players</span>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column - Profile Info */}
        <div className="order-2 lg:order-1 lg:col-span-1">
          {/* Profile Card */}
          <Card>
            <CardHeader className={`${getTeamColor(player.team)} text-white`}>
              <CardTitle className="flex justify-between items-center">
                <span>Player Profile</span>
                <Badge variant="outline" className="bg-white/20 text-white hover:bg-white/30">
                  #{player.jerseyNumber}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col items-center mb-6">
                <div className="w-40 h-40 rounded-full overflow-hidden bg-gray-100 mb-4 relative">
                  {player.image ? (
                    <Image
                      src={player.image || "/placeholder.svg"}
                      alt={player.name}
                      fill
                      sizes="160px"
                      className="object-cover"
                    />
                  ) : (
                    <div
                      className={`${getTeamColor(player.team)} w-full h-full flex items-center justify-center text-white text-4xl font-bold`}
                    >
                      {player.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                  )}
                </div>
                <h1 className="text-2xl font-bold">{player.name}</h1>
                <div className="text-gray-500 flex items-center gap-1">
                  <span>{player.team}</span>
                  <span>•</span>
                  <span>{player.position}</span>
                  <span>•</span>
                  <Badge variant="outline" className={getTeamColor(player.team) + " text-white"}>
                    {player.grade}
                  </Badge>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <UserRound className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Position</div>
                    <div className="font-medium">{player.position}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Height / Weight</div>
                    <div className="font-medium">
                      {player.height} / {player.weight}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Hometown</div>
                    <div className="font-medium">{player.hometown}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <CalendarDays className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">High School</div>
                    <div className="font-medium">{player.highSchool}</div>
                  </div>
                </div>
              </div>

              {player.achievements && player.achievements.length > 0 && (
                <div className="mt-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Trophy className="h-5 w-5 text-[#e31837]" />
                    <h3 className="font-bold text-gray-800">Achievements</h3>
                  </div>
                  <ul className="space-y-2">
                    {player.achievements.map((achievement, idx) => (
                      <li key={idx} className="text-sm flex items-start gap-2">
                        <Award className="h-4 w-4 text-yellow-500 mt-0.5 shrink-0" />
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right column - Stats and Tabs */}
        <div className="order-1 lg:order-2 lg:col-span-2">
          <Tabs defaultValue="overview">
            <div className="bg-[#0a2240] p-1 rounded-t-md">
              <TabsList className="grid w-full grid-cols-4 bg-transparent gap-1">
                <TabsTrigger
                  value="overview"
                  className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                >
                  Overview
                </TabsTrigger>
                <TabsTrigger
                  value="stats"
                  className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                >
                  Statistics
                </TabsTrigger>
                <TabsTrigger
                  value="highlights"
                  className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                >
                  Highlights
                </TabsTrigger>
                <TabsTrigger
                  value="media"
                  className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
                >
                  Media
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="bg-white border border-t-0 rounded-b-md p-6">
              <TabsContent value="overview" className="m-0">
                <div className="space-y-6">
                  <div>
                    <h2 className="text-xl font-bold mb-2">Bio</h2>
                    <p className="text-gray-700">{player.bio}</p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <StatCard
                      label="PPG"
                      value={player.stats.pointsPerGame.toFixed(1)}
                      icon={<BarChart3 className="h-5 w-5" />}
                      isHighlighted={true}
                    />
                    <StatCard
                      label="RPG"
                      value={player.stats.reboundsPerGame.toFixed(1)}
                      icon={<BarChart3 className="h-5 w-5" />}
                    />
                    <StatCard
                      label="APG"
                      value={player.stats.assistsPerGame.toFixed(1)}
                      icon={<BarChart3 className="h-5 w-5" />}
                    />
                    <StatCard
                      label="SPG"
                      value={player.stats.stealsPerGame.toFixed(1)}
                      icon={<BarChart3 className="h-5 w-5" />}
                    />
                  </div>

                  <div className="p-4 bg-gray-50 rounded-md text-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6">
                      <div className="font-medium text-gray-700">Shooting Splits:</div>
                      <div className="flex gap-4">
                        <div>
                          <span className="text-xs text-gray-500">FG%</span>
                          <div className="font-bold">{player.stats.fieldGoalPercentage.toFixed(1)}%</div>
                        </div>
                        <div>
                          <span className="text-xs text-gray-500">3P%</span>
                          <div className="font-bold">{player.stats.threePointPercentage.toFixed(1)}%</div>
                        </div>
                        <div>
                          <span className="text-xs text-gray-500">FT%</span>
                          <div className="font-bold">{player.stats.freeThrowPercentage.toFixed(1)}%</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="stats" className="m-0">
                <div className="space-y-6">
                  <h2 className="text-xl font-bold mb-2">2024-2025 Season Statistics</h2>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="text-left p-2 border">Category</th>
                          <th className="text-center p-2 border">Value</th>
                          <th className="text-center p-2 border">Team Rank</th>
                          <th className="text-center p-2 border">Conference Rank</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Points Per Game</td>
                          <td className="p-2 border text-center">{player.stats.pointsPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">1st</td>
                          <td className="p-2 border text-center">2nd</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Rebounds Per Game</td>
                          <td className="p-2 border text-center">{player.stats.reboundsPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">3rd</td>
                          <td className="p-2 border text-center">8th</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Assists Per Game</td>
                          <td className="p-2 border text-center">{player.stats.assistsPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">2nd</td>
                          <td className="p-2 border text-center">4th</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Steals Per Game</td>
                          <td className="p-2 border text-center">{player.stats.stealsPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">1st</td>
                          <td className="p-2 border text-center">3rd</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Blocks Per Game</td>
                          <td className="p-2 border text-center">{player.stats.blocksPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">4th</td>
                          <td className="p-2 border text-center">12th</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Field Goal %</td>
                          <td className="p-2 border text-center">{player.stats.fieldGoalPercentage.toFixed(1)}%</td>
                          <td className="p-2 border text-center">3rd</td>
                          <td className="p-2 border text-center">7th</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Three Point %</td>
                          <td className="p-2 border text-center">{player.stats.threePointPercentage.toFixed(1)}%</td>
                          <td className="p-2 border text-center">2nd</td>
                          <td className="p-2 border text-center">5th</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Free Throw %</td>
                          <td className="p-2 border text-center">{player.stats.freeThrowPercentage.toFixed(1)}%</td>
                          <td className="p-2 border text-center">1st</td>
                          <td className="p-2 border text-center">3rd</td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                          <td className="p-2 border font-medium">Minutes Per Game</td>
                          <td className="p-2 border text-center">{player.stats.minutesPerGame.toFixed(1)}</td>
                          <td className="p-2 border text-center">1st</td>
                          <td className="p-2 border text-center">6th</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-md">
                    <h3 className="font-bold mb-2">Statistical Analysis</h3>
                    <p className="text-sm text-gray-700">
                      {player.name} ranks among the top performers in the conference in several key statistical
                      categories. His efficiency and production have been crucial to {player.team}'s success throughout
                      the 2024-2025 season.
                    </p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="highlights" className="m-0">
                <div className="space-y-6">
                  <h2 className="text-xl font-bold mb-2">Season Highlights</h2>

                  {player.highlights && player.highlights.length > 0 ? (
                    <div className="space-y-4">
                      {player.highlights.map((highlight, idx) => (
                        <div key={idx} className="p-4 bg-gray-50 rounded-md flex gap-3">
                          <div className="h-8 w-8 rounded-full bg-[#0a2240] text-white flex items-center justify-center font-bold shrink-0">
                            {idx + 1}
                          </div>
                          <div>
                            <p className="text-gray-700">{highlight}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 bg-gray-50 rounded-md text-center">
                      <p className="text-gray-500">No highlight data available</p>
                    </div>
                  )}

                  <div className="my-6">
                    <h3 className="font-bold mb-3">Game-by-Game Performance</h3>
                    <div className="h-64 border rounded-md flex items-center justify-center">
                      <p className="text-gray-500">Game-by-game statistics chart will be available soon</p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="media" className="m-0">
                <PlayerMedia playerId={player.id} playerName={player.name} team={player.team} />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

interface StatCardProps {
  label: string
  value: string
  icon: React.ReactNode
  isHighlighted?: boolean
}

function StatCard({ label, value, icon, isHighlighted = false }: StatCardProps) {
  return (
    <div
      className={`p-4 rounded-md flex flex-col items-center justify-center ${
        isHighlighted ? "bg-[#e31837] text-white" : "bg-gray-100"
      }`}
    >
      <div className={`${isHighlighted ? "text-white/80" : "text-gray-500"} mb-1`}>{icon}</div>
      <div className="text-2xl font-bold">{value}</div>
      <div className={`text-xs ${isHighlighted ? "text-white/80" : "text-gray-500"}`}>{label}</div>
    </div>
  )
}

