import BasketballRankings from "@/basketball-rankings"
import PlayerRankings from "@/player-rankings"
import Schedules from "@/schedules"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarDays, Medal, TrendingUp, Users } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { TeamsRosterTab } from "@/components/teams-roster-tab"
import { RosterSearch } from "@/components/roster-search"

export default function HomePage() {
  // Featured game data
  const featuredGame = {
    homeTeam: "Fort Hill",
    homeScore: 72,
    awayTeam: "Allegany",
    awayScore: 68,
    date: "March 5, 2025",
    location: "Fort Hill High School Gymnasium",
  }

  // Top players data - Updated with players from our rosters
  const topPlayers = [
    { name: "Chris Manhertz", school: "Allegany", stat: "24.5 PPG" },
    { name: "Will Metz", school: "Mountain Ridge", stat: "10.2 RPG" },
    { name: "Tavin Willis", school: "Fort Hill", stat: "7.3 APG" },
  ]

  // Recent news data
  const recentNews = [
    { title: "Fort Hill clinches conference title with win over Allegany", date: "March 5, 2025" },
    { title: "Chris Manhertz named Player of the Week", date: "March 3, 2025" },
    { title: "Mountain Ridge upsets Southern Garrett in overtime thriller", date: "February 28, 2025" },
  ]

  return (
    <div className="bg-gray-50">
      {/* Hero section */}
      <div className="bg-[url('/placeholder.svg?height=500&width=1920')] bg-cover bg-center">
        <div className="bg-black/50 py-16">
          <div className="container mx-auto px-4 text-center text-white">
            <div className="flex justify-center mb-6">
              <div className="relative w-[140px] h-[140px]">
                <Image
                  src="/images/wmsn-logo.png"
                  alt="Western Maryland Sports Network Logo"
                  fill
                  sizes="140px"
                  className="object-contain"
                  style={{ background: "transparent" }}
                  priority
                />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Western Maryland Basketball</h1>
            <p className="text-xl max-w-2xl mx-auto">Complete coverage of high school basketball in Western Maryland</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-4 -mb-4">
        <Card className="bg-white shadow-md">
          <CardContent className="p-4">
            <h3 className="text-lg font-bold mb-2">Player Search</h3>
            <RosterSearch />
          </CardContent>
        </Card>
      </div>

      {/* Rest of the page content remains the same */}
      {/* Quick stats */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 -mt-12">
          <Link href="/standings">
            <Card className="bg-white shadow-lg border-t-4 border-[#0a2240] hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-[#0a2240]/10 p-3 rounded-full">
                    <Medal className="h-6 w-6 text-[#0a2240]" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Top Team</p>
                    <h3 className="text-lg font-bold">Fort Hill Sentinels</h3>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/players">
            <Card className="bg-white shadow-lg border-t-4 border-[#e31837] hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-[#e31837]/10 p-3 rounded-full">
                    <TrendingUp className="h-6 w-6 text-[#e31837]" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Top Scorer</p>
                    <h3 className="text-lg font-bold">Chris Manhertz</h3>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/schedules">
            <Card className="bg-white shadow-lg border-t-4 border-[#0a2240] hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-[#0a2240]/10 p-3 rounded-full">
                    <CalendarDays className="h-6 w-6 text-[#0a2240]" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Next Game</p>
                    <h3 className="text-lg font-bold">Mar 22 - MR vs BW</h3>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/teams">
            <Card className="bg-white shadow-lg border-t-4 border-[#e31837] hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-[#e31837]/10 p-3 rounded-full">
                    <Users className="h-6 w-6 text-[#e31837]" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Teams</p>
                    <h3 className="text-lg font-bold">6 WMAC Teams</h3>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* Featured content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Featured game */}
          <Card className="bg-white shadow-md col-span-1">
            <CardHeader className="bg-[#0a2240] text-white">
              <CardTitle className="text-lg">Featured Game</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-lg">
                    FH
                  </div>
                  <h3 className="font-bold">Fort Hill</h3>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">
                    {featuredGame.homeScore} - {featuredGame.awayScore}
                  </div>
                  <div className="text-xs text-gray-500">FINAL</div>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-lg">
                    AL
                  </div>
                  <h3 className="font-bold">Allegany</h3>
                </div>
              </div>
              <div className="text-sm text-gray-500 text-center">
                <p>{featuredGame.date}</p>
                <p>{featuredGame.location}</p>
              </div>
              <div className="mt-4 text-center">
                <Link href="/schedules" className="text-[#e31837] text-sm font-semibold hover:underline">
                  View Game Details
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Top players */}
          <Card className="bg-white shadow-md col-span-1">
            <CardHeader className="bg-[#0a2240] text-white">
              <CardTitle className="text-lg">Top Performers</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {topPlayers.map((player, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 pb-3 border-b border-gray-100 last:border-0 last:pb-0"
                  >
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-bold text-sm">
                      {player.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{player.name}</h4>
                      <p className="text-xs text-gray-500">{player.school}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-[#e31837]">{player.stat}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Link href="/players" className="text-[#e31837] text-sm font-semibold hover:underline">
                  View All Stats
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Recent news */}
          <Card className="bg-white shadow-md col-span-1">
            <CardHeader className="bg-[#0a2240] text-white">
              <CardTitle className="text-lg">Recent News</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {recentNews.map((news, index) => (
                  <div key={index} className="pb-3 border-b border-gray-100 last:border-0 last:pb-0">
                    <Link href="/news">
                      <h4 className="font-semibold hover:text-[#e31837] cursor-pointer">{news.title}</h4>
                    </Link>
                    <p className="text-xs text-gray-500 mt-1">{news.date}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <Link href="/news" className="text-[#e31837] text-sm font-semibold hover:underline">
                  View All News
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main content tabs */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Quick Access</h2>
          <Link href="/standings" className="text-[#e31837] font-semibold hover:underline">
            View Full Standings →
          </Link>
        </div>

        <Tabs defaultValue="teams" className="w-full">
          <div className="bg-[#0a2240] p-1 rounded-t-md">
            <TabsList className="grid w-full grid-cols-4 bg-transparent gap-1">
              <TabsTrigger
                value="teams"
                className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
              >
                Team Rankings
              </TabsTrigger>
              <TabsTrigger
                value="players"
                className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
              >
                Player Rankings
              </TabsTrigger>
              <TabsTrigger
                value="schedules"
                className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
              >
                Schedules
              </TabsTrigger>
              <TabsTrigger
                value="rosters"
                className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
              >
                Teams & Rosters
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="bg-white shadow-md rounded-b-md p-6">
            <TabsContent value="teams">
              <BasketballRankings />
            </TabsContent>

            <TabsContent value="players">
              <PlayerRankings />
            </TabsContent>

            <TabsContent value="schedules">
              <Schedules />
            </TabsContent>

            <TabsContent value="rosters">
              <TeamsRosterTab />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  )
}

