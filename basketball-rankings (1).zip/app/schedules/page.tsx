import Schedules from "@/schedules"

export default function SchedulesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Western Maryland Basketball Schedules</h1>
        <p className="text-gray-500">Game schedules and results for the 2024-2025 season</p>
      </div>

      <Schedules />
    </div>
  )
}

