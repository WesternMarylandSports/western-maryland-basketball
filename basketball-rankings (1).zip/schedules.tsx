"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Game {
  id: string
  homeTeam: string
  awayTeam: string
  date: string
  time: string
  location: string
  isCompleted: boolean
  homeScore?: number
  awayScore?: number
}

export default function Schedules() {
  const teams = ["Fort Hill", "Allegany", "Southern Garrett", "Mountain Ridge", "Northern Garrett", "Bishop Walsh"]

  const [selectedMonth, setSelectedMonth] = useState("March")

  // Sample schedule data
  const games: Game[] = [
    {
      id: "game1",
      homeTeam: "Fort Hill",
      awayTeam: "Allegany",
      date: "March 5, 2025",
      time: "7:00 PM",
      location: "Fort Hill High School Gymnasium",
      isCompleted: true,
      homeScore: 72,
      awayScore: 68,
    },
    {
      id: "game2",
      homeTeam: "Southern Garrett",
      awayTeam: "Mountain Ridge",
      date: "March 8, 2025",
      time: "6:30 PM",
      location: "Southern Garrett High School",
      isCompleted: true,
      homeScore: 65,
      awayScore: 70,
    },
    {
      id: "game3",
      homeTeam: "Bishop Walsh",
      awayTeam: "Northern Garrett",
      date: "March 12, 2025",
      time: "7:00 PM",
      location: "Bishop Walsh School Gymnasium",
      isCompleted: true,
      homeScore: 58,
      awayScore: 62,
    },
    {
      id: "game4",
      homeTeam: "Allegany",
      awayTeam: "Mountain Ridge",
      date: "March 15, 2025",
      time: "7:00 PM",
      location: "Allegany High School",
      isCompleted: true,
      homeScore: 75,
      awayScore: 67,
    },
    {
      id: "game5",
      homeTeam: "Northern Garrett",
      awayTeam: "Fort Hill",
      date: "March 19, 2025",
      time: "6:30 PM",
      location: "Northern Garrett High School",
      isCompleted: true,
      homeScore: 61,
      awayScore: 79,
    },
    {
      id: "game6",
      homeTeam: "Mountain Ridge",
      awayTeam: "Bishop Walsh",
      date: "March 22, 2025",
      time: "7:00 PM",
      location: "Mountain Ridge High School",
      isCompleted: false,
    },
    {
      id: "game7",
      homeTeam: "Fort Hill",
      awayTeam: "Southern Garrett",
      date: "March 26, 2025",
      time: "7:00 PM",
      location: "Fort Hill High School Gymnasium",
      isCompleted: false,
    },
    {
      id: "game8",
      homeTeam: "Allegany",
      awayTeam: "Northern Garrett",
      date: "March 29, 2025",
      time: "6:30 PM",
      location: "Allegany High School",
      isCompleted: false,
    },
    {
      id: "game9",
      homeTeam: "Bishop Walsh",
      awayTeam: "Fort Hill",
      date: "April 2, 2025",
      time: "7:00 PM",
      location: "Bishop Walsh School Gymnasium",
      isCompleted: false,
    },
    {
      id: "game10",
      homeTeam: "Southern Garrett",
      awayTeam: "Allegany",
      date: "April 5, 2025",
      time: "7:00 PM",
      location: "Southern Garrett High School",
      isCompleted: false,
    },
    {
      id: "game11",
      homeTeam: "Mountain Ridge",
      awayTeam: "Northern Garrett",
      date: "April 9, 2025",
      time: "6:30 PM",
      location: "Mountain Ridge High School",
      isCompleted: false,
    },
    {
      id: "game12",
      homeTeam: "Fort Hill",
      awayTeam: "Mountain Ridge",
      date: "April 12, 2025",
      time: "7:00 PM",
      location: "Fort Hill High School Gymnasium",
      isCompleted: false,
    },
  ]

  // Filter games by month
  const filteredGames = games.filter((game) => game.date.includes(selectedMonth))

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="bg-primary/5">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
          <div>
            <CardTitle className="text-2xl">Western Maryland Basketball Schedules</CardTitle>
            <CardDescription>Game schedules for the 2024-2025 season</CardDescription>
          </div>
          <div className="w-full sm:w-48">
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger>
                <SelectValue placeholder="Select Month" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="March">March 2025</SelectItem>
                <SelectItem value="April">April 2025</SelectItem>
                <SelectItem value="May">May 2025</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue={teams[0]} className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-6">
            {teams.map((team) => (
              <TabsTrigger key={team} value={team} className="text-xs sm:text-sm">
                {team}
              </TabsTrigger>
            ))}
          </TabsList>

          {teams.map((team) => (
            <TabsContent key={team} value={team} className="p-4">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Upcoming Games</h3>
                  <div className="space-y-4">
                    {filteredGames
                      .filter((game) => !game.isCompleted && (game.homeTeam === team || game.awayTeam === team))
                      .map((game) => (
                        <GameCard key={game.id} game={game} team={team} />
                      ))}
                    {filteredGames.filter(
                      (game) => !game.isCompleted && (game.homeTeam === team || game.awayTeam === team),
                    ).length === 0 && (
                      <p className="text-muted-foreground text-sm italic">
                        No upcoming games scheduled for this month.
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Recent Results</h3>
                  <div className="space-y-4">
                    {filteredGames
                      .filter((game) => game.isCompleted && (game.homeTeam === team || game.awayTeam === team))
                      .map((game) => (
                        <GameCard key={game.id} game={game} team={team} />
                      ))}
                    {filteredGames.filter(
                      (game) => game.isCompleted && (game.homeTeam === team || game.awayTeam === team),
                    ).length === 0 && (
                      <p className="text-muted-foreground text-sm italic">No completed games for this month.</p>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}

interface GameCardProps {
  game: Game
  team: string
}

function GameCard({ game, team }: GameCardProps) {
  const isHomeTeam = game.homeTeam === team
  const opponent = isHomeTeam ? game.awayTeam : game.homeTeam
  const location = isHomeTeam ? "Home" : "Away"

  // Determine if the selected team won, lost, or the game is upcoming
  let result = ""
  let resultClass = ""

  if (game.isCompleted && game.homeScore !== undefined && game.awayScore !== undefined) {
    if (isHomeTeam) {
      if (game.homeScore > game.awayScore) {
        result = "Win"
        resultClass = "bg-green-100 text-green-800"
      } else {
        result = "Loss"
        resultClass = "bg-red-100 text-red-800"
      }
    } else {
      if (game.awayScore > game.homeScore) {
        result = "Win"
        resultClass = "bg-green-100 text-green-800"
      } else {
        result = "Loss"
        resultClass = "bg-red-100 text-red-800"
      }
    }
  }

  return (
    <div className="border rounded-lg p-4 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h4 className="font-medium">{isHomeTeam ? `vs ${opponent}` : `@ ${opponent}`}</h4>
            {game.isCompleted && (
              <Badge variant="outline" className={resultClass}>
                {result}
              </Badge>
            )}
            {!game.isCompleted && (
              <Badge variant="outline" className="bg-blue-100 text-blue-800">
                Upcoming
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              <span>{game.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              <span>{game.time}</span>
            </div>
          </div>

          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            <span>{game.location}</span>
          </div>
        </div>

        {game.isCompleted && game.homeScore !== undefined && game.awayScore !== undefined && (
          <div className="flex items-center gap-2 sm:text-right">
            <div className="flex flex-col items-center">
              <span className="text-xs font-medium">{game.homeTeam}</span>
              <span className="text-2xl font-bold">{game.homeScore}</span>
            </div>
            <span className="text-xl">-</span>
            <div className="flex flex-col items-center">
              <span className="text-xs font-medium">{game.awayTeam}</span>
              <span className="text-2xl font-bold">{game.awayScore}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

