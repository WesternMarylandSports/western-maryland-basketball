import { ArrowDown, ArrowUp, Minus } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface TeamRanking {
  rank: number
  previousRank: number
  name: string
  mascot: string
  wins: number
  losses: number
  conference: string
  points: number
  streak: string
}

export default function BasketballRankings() {
  const rankings: TeamRanking[] = [
    {
      rank: 1,
      previousRank: 1,
      name: "Fort Hill",
      mascot: "Sentinels",
      wins: 15,
      losses: 10,
      conference: "WMAC",
      points: 78.5,
      streak: "L1",
    },
    {
      rank: 2,
      previousRank: 3,
      name: "Mountain Ridge",
      mascot: "Miners",
      wins: 15,
      losses: 10,
      conference: "WMAC",
      points: 72.3,
      streak: "L1",
    },
    {
      rank: 3,
      previousRank: 2,
      name: "Southern Garrett",
      mascot: "Rams",
      wins: 13,
      losses: 11,
      conference: "WMAC",
      points: 70.1,
      streak: "L1",
    },
    {
      rank: 4,
      previousRank: 5,
      name: "Allegany",
      mascot: "Campers",
      wins: 11,
      losses: 13,
      conference: "WMAC",
      points: 68.7,
      streak: "L1",
    },
    {
      rank: 5,
      previousRank: 4,
      name: "Northern Garrett",
      mascot: "Huskies",
      wins: 10,
      losses: 13,
      conference: "WMAC",
      points: 65.2,
      streak: "L3",
    },
    {
      rank: 6,
      previousRank: 6,
      name: "Bishop Walsh",
      mascot: "Spartans",
      wins: 6,
      losses: 19,
      conference: "WMAC",
      points: 62.8,
      streak: "L1",
    },
  ]

  const getRankChange = (current: number, previous: number) => {
    if (current < previous) return <ArrowUp className="text-green-500 h-4 w-4" />
    if (current > previous) return <ArrowDown className="text-red-500 h-4 w-4" />
    return <Minus className="text-gray-500 h-4 w-4" />
  }

  // Team colors for MaxPreps-style display
  const getTeamColor = (team: string) => {
    switch (team) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Team Rankings</h2>
        <div className="text-sm text-gray-500">Updated: March 20, 2025</div>
      </div>

      <div className="overflow-hidden rounded-lg border">
        <Table>
          <TableHeader className="bg-[#f8f9fa]">
            <TableRow>
              <TableHead className="w-[60px] font-bold">Rank</TableHead>
              <TableHead className="font-bold">Team</TableHead>
              <TableHead className="text-center font-bold">Record</TableHead>
              <TableHead className="text-center font-bold">Win %</TableHead>
              <TableHead className="text-center font-bold">PPG</TableHead>
              <TableHead className="text-center font-bold">Streak</TableHead>
              <TableHead className="text-center font-bold">Last 10</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rankings.map((team) => {
              const winPercentage = ((team.wins / (team.wins + team.losses)) * 100).toFixed(1)

              return (
                <TableRow key={team.name} className="hover:bg-gray-50 cursor-pointer">
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-1">
                      <div className="w-6 h-6 rounded-full bg-[#0a2240] text-white flex items-center justify-center text-xs">
                        {team.rank}
                      </div>
                      {getRankChange(team.rank, team.previousRank)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-full ${getTeamColor(team.name)} text-white flex items-center justify-center font-bold`}
                      >
                        {team.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <div>
                        <div className="font-semibold">{team.name}</div>
                        <div className="text-xs text-gray-500">{team.mascot}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center font-medium">
                    {team.wins}-{team.losses}
                  </TableCell>
                  <TableCell className="text-center">{winPercentage}%</TableCell>
                  <TableCell className="text-center">{team.points}</TableCell>
                  <TableCell className="text-center">
                    <Badge
                      variant="outline"
                      className={
                        team.streak.startsWith("W") ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }
                    >
                      {team.streak}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <div key={i} className="w-2 h-2 rounded-full bg-green-500"></div>
                        ))}
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <div key={i} className="w-2 h-2 rounded-full bg-red-500"></div>
                        ))}
                    </div>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <Card>
          <CardHeader className="bg-[#0a2240] text-white">
            <CardTitle className="text-lg">Offensive Leaders</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <Table>
              <TableHeader className="bg-[#f8f9fa]">
                <TableRow>
                  <TableHead className="font-bold">Team</TableHead>
                  <TableHead className="text-center font-bold">PPG</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...rankings]
                  .sort((a, b) => b.points - a.points)
                  .slice(0, 3)
                  .map((team) => (
                    <TableRow key={`off-${team.name}`}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-8 h-8 rounded-full ${getTeamColor(team.name)} text-white flex items-center justify-center font-bold text-xs`}
                          >
                            {team.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </div>
                          <div className="font-medium">{team.name}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-bold">{team.points}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-[#0a2240] text-white">
            <CardTitle className="text-lg">Win Percentage Leaders</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <Table>
              <TableHeader className="bg-[#f8f9fa]">
                <TableRow>
                  <TableHead className="font-bold">Team</TableHead>
                  <TableHead className="text-center font-bold">Win %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...rankings]
                  .sort((a, b) => b.wins / (b.wins + b.losses) - a.wins / (a.wins + a.losses))
                  .slice(0, 3)
                  .map((team) => {
                    const winPercentage = ((team.wins / (team.wins + team.losses)) * 100).toFixed(1)

                    return (
                      <TableRow key={`win-${team.name}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-8 h-8 rounded-full ${getTeamColor(team.name)} text-white flex items-center justify-center font-bold text-xs`}
                            >
                              {team.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div className="font-medium">{team.name}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-center font-bold">{winPercentage}%</TableCell>
                      </TableRow>
                    )
                  })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

