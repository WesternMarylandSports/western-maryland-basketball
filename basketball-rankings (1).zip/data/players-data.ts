import { teamsData } from "./teams-data"

export interface PlayerStats {
  pointsPerGame: number
  reboundsPerGame: number
  assistsPerGame: number
  stealsPerGame: number
  blocksPerGame: number
  fieldGoalPercentage: number
  threePointPercentage: number
  freeThrowPercentage: number
  minutesPerGame: number
}

export interface PlayerProfile {
  id: string
  name: string
  team: string
  position: string
  jerseyNumber: string
  height: string
  weight: string
  grade: string
  hometown: string
  highSchool: string
  image?: string
  bio: string
  stats: PlayerStats
  highlights?: string[]
  achievements?: string[]
}

// Generate default stats for players without specific stats
const generateDefaultStats = (): PlayerStats => {
  return {
    pointsPerGame: Math.floor(Math.random() * 10) + 5,
    reboundsPerGame: Math.floor(Math.random() * 5) + 2,
    assistsPerGame: Math.floor(Math.random() * 4) + 1,
    stealsPerGame: Math.floor(Math.random() * 2) + 0.5,
    blocksPerGame: Math.floor(Math.random() * 1) + 0.1,
    fieldGoalPercentage: Math.floor(Math.random() * 15) + 40,
    threePointPercentage: Math.floor(Math.random() * 15) + 30,
    freeThrowPercentage: Math.floor(Math.random() * 15) + 65,
    minutesPerGame: Math.floor(Math.random() * 15) + 15,
  }
}

// Generate a default bio for players
const generateDefaultBio = (name: string, team: string, position: string, grade: string): string => {
  const positions: Record<string, string> = {
    G: "guard",
    PG: "point guard",
    SG: "shooting guard",
    F: "forward",
    SF: "small forward",
    PF: "power forward",
    C: "center",
  }

  const positionName = positions[position] || position
  const gradeText = grade === "Sr" ? "senior" : grade === "Jr" ? "junior" : grade === "So" ? "sophomore" : "freshman"

  return `${name} is a ${gradeText} ${positionName} for the ${team} basketball team. He has been a valuable contributor to the team's success during the 2024-2025 season, showing dedication both on the court and in the classroom.`
}

// Featured players with detailed profiles
const featuredPlayers: PlayerProfile[] = [
  {
    id: "chris-manhertz",
    name: "Chris Manhertz",
    team: "Allegany",
    position: "PG",
    jerseyNumber: "1",
    height: "5'10\"",
    weight: "165 lbs",
    grade: "Sr",
    hometown: "Cumberland, MD",
    highSchool: "Allegany High School",
    bio: "Chris Manhertz is a dynamic point guard known for his explosive scoring ability and court vision. A four-year varsity player for the Campers, Manhertz has developed into one of the premier guards in Western Maryland. His leadership and clutch performances have been crucial to Allegany's success this season.",
    stats: {
      pointsPerGame: 24.5,
      reboundsPerGame: 4.2,
      assistsPerGame: 5.8,
      stealsPerGame: 2.3,
      blocksPerGame: 0.4,
      fieldGoalPercentage: 48.5,
      threePointPercentage: 38.2,
      freeThrowPercentage: 82.6,
      minutesPerGame: 32.4,
    },
    highlights: [
      "Scored 38 points in the rivalry game against Fort Hill",
      "Recorded a triple-double (22 pts, 11 reb, 10 ast) against Northern Garrett",
      "Hit the game-winning three-pointer at the buzzer against Mountain Ridge",
    ],
    achievements: [
      "2-time All-WMAC First Team (2023, 2024)",
      "Cumberland Times-News Player of the Week (5 times)",
      "School record for most three-pointers in a season (87)",
    ],
  },
  {
    id: "marcus-johnson",
    name: "Marcus Johnson",
    team: "Fort Hill",
    position: "SG",
    jerseyNumber: "4",
    height: "6'3\"",
    weight: "185 lbs",
    grade: "Sr",
    hometown: "Cumberland, MD",
    highSchool: "Fort Hill High School",
    bio: "Marcus Johnson is a versatile shooting guard with excellent scoring ability from all three levels. As a four-year varsity player and two-year captain for the Sentinels, Johnson has been the cornerstone of Fort Hill's offense. His combination of size, skill, and basketball IQ has caught the attention of several Division II college programs.",
    stats: {
      pointsPerGame: 24.0,
      reboundsPerGame: 4.3,
      assistsPerGame: 3.8,
      stealsPerGame: 1.9,
      blocksPerGame: 0.7,
      fieldGoalPercentage: 50.2,
      threePointPercentage: 40.5,
      freeThrowPercentage: 78.3,
      minutesPerGame: 31.8,
    },
    highlights: [
      "Career-high 42 points against Bishop Walsh",
      "30+ points in three consecutive games during January",
      "Game-winning layup in overtime against Allegany",
    ],
    achievements: [
      "All-WMAC First Team (2023, 2024)",
      "Area scoring leader in 2024",
      "1,500+ career points milestone reached",
    ],
  },
  {
    id: "will-metz",
    name: "Will Metz",
    team: "Mountain Ridge",
    position: "G",
    jerseyNumber: "1",
    height: "5'10\"",
    weight: "170 lbs",
    grade: "Sr",
    hometown: "Frostburg, MD",
    highSchool: "Mountain Ridge High School",
    bio: "Will Metz is known for his tenacious defense and floor leadership. A true floor general, Metz excels at controlling the pace of the game and getting his teammates involved. His development as a scorer this season has made him one of the most improved players in the conference and a crucial piece to Mountain Ridge's success.",
    stats: {
      pointsPerGame: 17.8,
      reboundsPerGame: 3.2,
      assistsPerGame: 6.5,
      stealsPerGame: 2.8,
      blocksPerGame: 0.2,
      fieldGoalPercentage: 44.7,
      threePointPercentage: 37.1,
      freeThrowPercentage: 85.9,
      minutesPerGame: 30.5,
    },
    highlights: [
      "12 assists against Northern Garrett",
      "Season-high 29 points versus Bishop Walsh",
      "7 steals in a single game against Southern Garrett",
    ],
    achievements: [
      "All-WMAC Second Team (2024)",
      "Team captain for two seasons",
      "School record for assists in a season (156)",
    ],
  },
  {
    id: "cameron-breighner",
    name: "Cameron Breighner",
    team: "Mountain Ridge",
    position: "PF",
    jerseyNumber: "32",
    height: "6'5\"",
    weight: "210 lbs",
    grade: "Jr",
    hometown: "Frostburg, MD",
    highSchool: "Mountain Ridge High School",
    bio: "Cameron Breighner has emerged as one of the premier post players in Western Maryland. With excellent footwork and a soft touch around the basket, Breighner is a double-double machine for the Miners. Despite only being a junior, he's already drawing interest from multiple college programs due to his rebounding prowess and shot-blocking ability.",
    stats: {
      pointsPerGame: 12.3,
      reboundsPerGame: 10.5,
      assistsPerGame: 1.2,
      stealsPerGame: 0.5,
      blocksPerGame: 2.8,
      fieldGoalPercentage: 57.8,
      threePointPercentage: 18.2,
      freeThrowPercentage: 65.3,
      minutesPerGame: 28.7,
    },
    highlights: [
      "20 points and 18 rebounds against Fort Hill",
      "6 blocks in a game versus Allegany",
      "Four straight double-doubles in February",
    ],
    achievements: [
      "All-WMAC Second Team (2024)",
      "Led conference in rebounds and blocks",
      "Team defensive player of the year (2023, 2024)",
    ],
  },
  {
    id: "brandon-miller",
    name: "Brandon Miller",
    team: "Southern Garrett",
    position: "SF",
    jerseyNumber: "23",
    height: "6'4\"",
    weight: "190 lbs",
    grade: "Sr",
    hometown: "Oakland, MD",
    highSchool: "Southern Garrett High School",
    bio: "Brandon Miller is a smooth, athletic wing who can score from anywhere on the court. His versatility allows him to play multiple positions for the Rams, and his length makes him a disruptive defender. After missing three weeks with an ankle injury mid-season, Miller returned stronger than ever to lead Southern Garrett's playoff push.",
    stats: {
      pointsPerGame: 21.8,
      reboundsPerGame: 7.3,
      assistsPerGame: 2.5,
      stealsPerGame: 1.8,
      blocksPerGame: 0.9,
      fieldGoalPercentage: 49.3,
      threePointPercentage: 35.8,
      freeThrowPercentage: 74.2,
      minutesPerGame: 29.8,
    },
    highlights: [
      "35 points in his return game from injury",
      "Clutch three-pointer to force overtime against Northern Garrett",
      "26 points and 12 rebounds in playoff win",
    ],
    achievements: [
      "All-WMAC First Team (2024)",
      "Comeback Player of the Year nominee",
      "Selected for regional all-star game",
    ],
  },
]

// Generate profiles for all players from the roster data
export const playersData: PlayerProfile[] = [...featuredPlayers]

// Add all players from the team rosters
teamsData.forEach((team) => {
  team.players.forEach((player) => {
    // Skip if player is already in the featured players list
    if (featuredPlayers.some((fp) => fp.name === player.name)) {
      return
    }

    // Create a player ID from the name
    const playerId = player.name.toLowerCase().replace(/\s+/g, "-")

    // Add the player to the playersData array
    playersData.push({
      id: playerId,
      name: player.name,
      team: team.name,
      position: player.position,
      jerseyNumber: player.number,
      height: player.height,
      weight: `${Math.floor(Math.random() * 40) + 150} lbs`, // Random weight between 150-190 lbs
      grade: player.grade,
      hometown: `${["Cumberland", "Frostburg", "Oakland", "Accident", "Grantsville", "Westernport"][Math.floor(Math.random() * 6)]}, MD`,
      highSchool: `${team.name} High School`,
      bio: generateDefaultBio(player.name, team.name, player.position, player.grade),
      stats: generateDefaultStats(),
      highlights:
        player.grade === "Sr" || player.grade === "Jr"
          ? [
              `Season-high ${Math.floor(Math.random() * 15) + 10} points against ${teamsData[Math.floor(Math.random() * teamsData.length)].name}`,
              `Recorded ${Math.floor(Math.random() * 5) + 5} rebounds and ${Math.floor(Math.random() * 5) + 2} assists in win over ${teamsData[Math.floor(Math.random() * teamsData.length)].name}`,
            ]
          : undefined,
      achievements:
        player.grade === "Sr"
          ? [`${Math.floor(Math.random() * 2) + 1}-year varsity player`, `Team captain (2024-2025)`]
          : undefined,
    })
  })
})

export const getPlayerById = (id: string): PlayerProfile | undefined => {
  return playersData.find((player) => player.id === id)
}

