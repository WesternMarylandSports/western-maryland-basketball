export type Player = {
  name: string
  number: string
  position: string
  height: string
  grade: string
}

export type Team = {
  name: string
  mascot: string
  colors: {
    primary: string
    secondary: string
  }
  players: Player[]
}

export const teamsData: Team[] = [
  {
    name: "Allegany",
    mascot: "Campers",
    colors: {
      primary: "#0a2240",
      secondary: "#e31837",
    },
    players: [
      { name: "Chris Manhertz", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "Tyrell Washington", number: "2", position: "G", height: "6'0\"", grade: "Jr" },
      { name: "Darius Wilson", number: "3", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "Marcus Johnson", number: "4", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Jamal Brown", number: "5", position: "C", height: "6'6\"", grade: "Sr" },
      { name: "Elijah Thomas", number: "10", position: "G", height: "5'11\"", grade: "So" },
      { name: "Isaiah Williams", number: "11", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Caleb Anderson", number: "12", position: "F", height: "6'2\"", grade: "So" },
      { name: "Xavier Davis", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Zion Taylor", number: "14", position: "C", height: "6'5\"", grade: "So" },
      { name: "Jordan Miller", number: "15", position: "G", height: "5'10\"", grade: "Fr" },
      { name: "Aiden Harris", number: "20", position: "G", height: "5'11\"", grade: "Fr" },
      { name: "Noah Clark", number: "21", position: "F", height: "6'1\"", grade: "Fr" },
      { name: "Ethan Lewis", number: "22", position: "F", height: "6'2\"", grade: "Fr" },
      { name: "Mason Wright", number: "23", position: "C", height: "6'4\"", grade: "Fr" },
    ],
  },
  {
    name: "Fort Hill",
    mascot: "Sentinels",
    colors: {
      primary: "#0a2240",
      secondary: "#e31837",
    },
    players: [
      { name: "Jaden Yates", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "Tavin Willis", number: "2", position: "G", height: "6'0\"", grade: "Sr" },
      { name: "Mikey Allen", number: "3", position: "G", height: "5'11\"", grade: "Sr" },
      { name: "Deshaun Brown", number: "4", position: "F", height: "6'3\"", grade: "Sr" },
      { name: "Jabril Daniels", number: "5", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "Jayden Soto", number: "10", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Elijah Parker", number: "11", position: "G", height: "5'10\"", grade: "Jr" },
      { name: "Isaiah Coleman", number: "12", position: "F", height: "6'2\"", grade: "Jr" },
      { name: "Xavier Mitchell", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Zion Jackson", number: "14", position: "C", height: "6'5\"", grade: "Jr" },
      { name: "Jordan Turner", number: "15", position: "G", height: "5'8\"", grade: "So" },
      { name: "Aiden Rodriguez", number: "20", position: "G", height: "5'9\"", grade: "So" },
      { name: "Noah Martinez", number: "21", position: "F", height: "6'1\"", grade: "So" },
      { name: "Ethan Nguyen", number: "22", position: "F", height: "6'2\"", grade: "So" },
      { name: "Mason Thompson", number: "23", position: "C", height: "6'4\"", grade: "So" },
    ],
  },
  {
    name: "Mountain Ridge",
    mascot: "Miners",
    colors: {
      primary: "#000000",
      secondary: "#ffd700",
    },
    players: [
      { name: "Will Metz", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "Peyton Liller", number: "2", position: "G", height: "6'0\"", grade: "Sr" },
      { name: "Nate Washington", number: "3", position: "F", height: "6'3\"", grade: "Sr" },
      { name: "Jace Horner", number: "4", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "Bryce Snyder", number: "5", position: "C", height: "6'6\"", grade: "Sr" },
      { name: "Evan Darr", number: "10", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Landon Kight", number: "11", position: "G", height: "5'11\"", grade: "Jr" },
      { name: "Caleb Harden", number: "12", position: "F", height: "6'2\"", grade: "Jr" },
      { name: "Xavier Humbertson", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Zach Bratton", number: "14", position: "C", height: "6'5\"", grade: "Jr" },
      { name: "Jordan Wildesen", number: "15", position: "G", height: "5'8\"", grade: "So" },
      { name: "Aiden Stafford", number: "20", position: "G", height: "5'9\"", grade: "So" },
      { name: "Noah Logsdon", number: "21", position: "F", height: "6'1\"", grade: "So" },
      { name: "Ethan Sisler", number: "22", position: "F", height: "6'2\"", grade: "So" },
      { name: "Mason Metz", number: "23", position: "C", height: "6'4\"", grade: "So" },
    ],
  },
  {
    name: "Northern Garrett",
    mascot: "Huskies",
    colors: {
      primary: "#0a2240",
      secondary: "#ffffff",
    },
    players: [
      { name: "Michael Carter", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "David Smith", number: "2", position: "G", height: "6'0\"", grade: "Sr" },
      { name: "Robert Johnson", number: "3", position: "F", height: "6'3\"", grade: "Sr" },
      { name: "James Williams", number: "4", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "John Brown", number: "5", position: "C", height: "6'6\"", grade: "Sr" },
      { name: "William Jones", number: "10", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Richard Davis", number: "11", position: "G", height: "5'11\"", grade: "Jr" },
      { name: "Joseph Miller", number: "12", position: "F", height: "6'2\"", grade: "Jr" },
      { name: "Thomas Wilson", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Charles Moore", number: "14", position: "C", height: "6'5\"", grade: "Jr" },
      { name: "Daniel Taylor", number: "15", position: "G", height: "5'8\"", grade: "So" },
      { name: "Matthew Anderson", number: "20", position: "G", height: "5'9\"", grade: "So" },
      { name: "Anthony Thomas", number: "21", position: "F", height: "6'1\"", grade: "So" },
      { name: "Mark Jackson", number: "22", position: "F", height: "6'2\"", grade: "So" },
      { name: "Paul White", number: "23", position: "C", height: "6'4\"", grade: "So" },
    ],
  },
  {
    name: "Southern Garrett",
    mascot: "Rams",
    colors: {
      primary: "#00205b",
      secondary: "#ffffff",
    },
    players: [
      { name: "Xander Keller", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "Jace Broadwater", number: "2", position: "G", height: "6'0\"", grade: "Sr" },
      { name: "Brody Bosley", number: "3", position: "F", height: "6'3\"", grade: "Sr" },
      { name: "Grayson Bosley", number: "4", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "Jamal Brown", number: "5", position: "C", height: "6'6\"", grade: "Sr" },
      { name: "Elijah Thomas", number: "10", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Isaiah Williams", number: "11", position: "G", height: "5'11\"", grade: "Jr" },
      { name: "Caleb Anderson", number: "12", position: "F", height: "6'2\"", grade: "Jr" },
      { name: "Xavier Davis", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Zion Taylor", number: "14", position: "C", height: "6'5\"", grade: "Jr" },
      { name: "Jordan Miller", number: "15", position: "G", height: "5'8\"", grade: "So" },
      { name: "Aiden Harris", number: "20", position: "G", height: "5'9\"", grade: "So" },
      { name: "Noah Clark", number: "21", position: "F", height: "6'1\"", grade: "So" },
      { name: "Ethan Lewis", number: "22", position: "F", height: "6'2\"", grade: "So" },
      { name: "Mason Wright", number: "23", position: "C", height: "6'4\"", grade: "So" },
    ],
  },
  {
    name: "Bishop Walsh",
    mascot: "Spartans",
    colors: {
      primary: "#006400",
      secondary: "#ffffff",
    },
    players: [
      { name: "Kevin Harris", number: "1", position: "G", height: "5'10\"", grade: "Sr" },
      { name: "Brandon Lee", number: "2", position: "G", height: "6'0\"", grade: "Sr" },
      { name: "Tyler Scott", number: "3", position: "F", height: "6'3\"", grade: "Sr" },
      { name: "Justin Green", number: "4", position: "F", height: "6'4\"", grade: "Sr" },
      { name: "Aaron King", number: "5", position: "C", height: "6'6\"", grade: "Sr" },
      { name: "Derrick Baker", number: "10", position: "G", height: "5'9\"", grade: "Jr" },
      { name: "Eric Adams", number: "11", position: "G", height: "5'11\"", grade: "Jr" },
      { name: "Frank Nelson", number: "12", position: "F", height: "6'2\"", grade: "Jr" },
      { name: "Gary Hill", number: "13", position: "F", height: "6'3\"", grade: "Jr" },
      { name: "Henry Carter", number: "14", position: "C", height: "6'5\"", grade: "Jr" },
      { name: "Ian Evans", number: "15", position: "G", height: "5'8\"", grade: "So" },
      { name: "Jack Phillips", number: "20", position: "G", height: "5'9\"", grade: "So" },
      { name: "Kyle Morgan", number: "21", position: "F", height: "6'1\"", grade: "So" },
      { name: "Larry Cooper", number: "22", position: "F", height: "6'2\"", grade: "So" },
      { name: "Mike Rogers", number: "23", position: "C", height: "6'4\"", grade: "So" },
    ],
  },
]

