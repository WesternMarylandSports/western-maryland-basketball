import { TeamsRosterTab } from "@/components/teams-roster-tab"

export default function TeamsRosters() {
  return <TeamsRosterTab />
}

