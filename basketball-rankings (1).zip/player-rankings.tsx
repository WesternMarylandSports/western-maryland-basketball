import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface PlayerRanking {
  rank: number
  name: string
  school: string
  position: string
  year: string
  pointsPerGame: number
  rebounds: number
  assists: number
  steals: number
  blocks: number
}

export default function PlayerRankings() {
  const scoringLeaders: PlayerRanking[] = [
    {
      rank: 1,
      name: "Chris Manhertz",
      school: "Allegany",
      position: "PG",
      year: "Junior",
      pointsPerGame: 22.2,
      rebounds: 0.0,
      assists: 0.0,
      steals: 0.0,
      blocks: 0.0,
    },
    {
      rank: 2,
      name: "Jared Haskiell",
      school: "Southern",
      position: "PG",
      year: "Senior",
      pointsPerGame: 21.7,
      rebounds: 3.0,
      assists: 3.0,
      steals: 1.9,
      blocks: 0.4,
    },
    {
      rank: 3,
      name: "Brayden Upole",
      school: "Southern Garrett",
      position: "PG",
      year: "Senior",
      pointsPerGame: 14.1,
      rebounds: 3.3,
      assists: 2.5,
      steals: 1.8,
      blocks: 0.9,
    },
    {
      rank: 4,
      name: "Eli Imes",
      school: "Allegany",
      position: "SF",
      year: "Senior",
      pointsPerGame: 13.6,
      rebounds: 0.0,
      assists: 0.0,
      steals: 0.0,
      blocks: 0.0,
    },
    {
      rank: 5,
      name: "Liam Hamilton",
      school: "Fort Hill",
      position: "SF",
      year: "Junior",
      pointsPerGame: 13.0,
      rebounds: 0.0,
      assists: 0.0,
      steals: 0.0,
      blocks: 0.0,
    },
    {
      rank: 6,
      name: "Cameron Breighner",
      school: "Mountain Ridge",
      position: "PF",
      year: "Junior",
      pointsPerGame: 12.3,
      rebounds: 10.5,
      assists: 1.2,
      steals: 0.5,
      blocks: 2.8,
    },
  ]

  const reboundingLeaders = [...scoringLeaders].sort((a, b) => b.rebounds - a.rebounds)
  const assistLeaders = [...scoringLeaders].sort((a, b) => b.assists - a.assists)

  // Team colors for MaxPreps-style display
  const getTeamColor = (school: string) => {
    switch (school) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  const getPositionColor = (position: string) => {
    switch (position) {
      case "PG":
        return "bg-blue-500"
      case "SG":
        return "bg-green-500"
      case "SF":
        return "bg-yellow-500"
      case "PF":
        return "bg-orange-500"
      case "C":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getYearColor = (year: string) => {
    switch (year) {
      case "Freshman":
        return "bg-gray-200 text-gray-800"
      case "Sophomore":
        return "bg-blue-200 text-blue-800"
      case "Junior":
        return "bg-green-200 text-green-800"
      case "Senior":
        return "bg-purple-200 text-purple-800"
      default:
        return "bg-gray-200 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Player Rankings</h2>
        <div className="text-sm text-gray-500">2024-2025 Season</div>
      </div>

      <Tabs defaultValue="scoring" className="w-full">
        <div className="bg-[#0a2240] p-1 rounded-t-md">
          <TabsList className="grid w-full grid-cols-3 bg-transparent gap-1">
            <TabsTrigger
              value="scoring"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Scoring Leaders
            </TabsTrigger>
            <TabsTrigger
              value="rebounding"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Rebounding Leaders
            </TabsTrigger>
            <TabsTrigger
              value="assists"
              className="data-[state=active]:bg-white data-[state=active]:text-[#0a2240] text-white"
            >
              Assist Leaders
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="bg-white rounded-b-md border border-t-0">
          <TabsContent value="scoring" className="p-0 m-0">
            <PlayerTable
              players={scoringLeaders}
              statHighlight="pointsPerGame"
              getTeamColor={getTeamColor}
              getPositionColor={getPositionColor}
              getYearColor={getYearColor}
            />
          </TabsContent>

          <TabsContent value="rebounding" className="p-0 m-0">
            <PlayerTable
              players={reboundingLeaders}
              statHighlight="rebounds"
              getTeamColor={getTeamColor}
              getPositionColor={getPositionColor}
              getYearColor={getYearColor}
            />
          </TabsContent>

          <TabsContent value="assists" className="p-0 m-0">
            <PlayerTable
              players={assistLeaders}
              statHighlight="assists"
              getTeamColor={getTeamColor}
              getPositionColor={getPositionColor}
              getYearColor={getYearColor}
            />
          </TabsContent>
        </div>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <Card>
          <CardHeader className="bg-[#0a2240] text-white p-4">
            <CardTitle className="text-lg">Top Scorers</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {scoringLeaders.slice(0, 3).map((player, index) => (
              <div key={`scorer-${player.name}`} className="flex items-center gap-3 py-3 border-b last:border-0">
                <div className="font-bold text-lg text-gray-400 w-6">{index + 1}</div>
                <Avatar className="h-10 w-10 border-2 border-[#0a2240]">
                  <AvatarFallback className={`${getTeamColor(player.school)} text-white`}>
                    {player.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-semibold">{player.name}</div>
                  <div className="text-xs text-gray-500 flex items-center gap-1">
                    <span>{player.school}</span>
                    <span>•</span>
                    <span>{player.position}</span>
                    <span>•</span>
                    <span>{player.year}</span>
                  </div>
                </div>
                <div className="font-bold text-[#e31837]">{player.pointsPerGame.toFixed(1)}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-[#0a2240] text-white p-4">
            <CardTitle className="text-lg">Top Rebounders</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {reboundingLeaders.slice(0, 3).map((player, index) => (
              <div key={`rebounder-${player.name}`} className="flex items-center gap-3 py-3 border-b last:border-0">
                <div className="font-bold text-lg text-gray-400 w-6">{index + 1}</div>
                <Avatar className="h-10 w-10 border-2 border-[#0a2240]">
                  <AvatarFallback className={`${getTeamColor(player.school)} text-white`}>
                    {player.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-semibold">{player.name}</div>
                  <div className="text-xs text-gray-500 flex items-center gap-1">
                    <span>{player.school}</span>
                    <span>•</span>
                    <span>{player.position}</span>
                    <span>•</span>
                    <span>{player.year}</span>
                  </div>
                </div>
                <div className="font-bold text-[#e31837]">{player.rebounds.toFixed(1)}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-[#0a2240] text-white p-4">
            <CardTitle className="text-lg">Top Assisters</CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {assistLeaders.slice(0, 3).map((player, index) => (
              <div key={`assister-${player.name}`} className="flex items-center gap-3 py-3 border-b last:border-0">
                <div className="font-bold text-lg text-gray-400 w-6">{index + 1}</div>
                <Avatar className="h-10 w-10 border-2 border-[#0a2240]">
                  <AvatarFallback className={`${getTeamColor(player.school)} text-white`}>
                    {player.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-semibold">{player.name}</div>
                  <div className="text-xs text-gray-500 flex items-center gap-1">
                    <span>{player.school}</span>
                    <span>•</span>
                    <span>{player.position}</span>
                    <span>•</span>
                    <span>{player.year}</span>
                  </div>
                </div>
                <div className="font-bold text-[#e31837]">{player.assists.toFixed(1)}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

interface PlayerTableProps {
  players: PlayerRanking[]
  statHighlight: keyof PlayerRanking
  getTeamColor: (school: string) => string
  getPositionColor: (position: string) => string
  getYearColor: (year: string) => string
}

function PlayerTable({ players, statHighlight, getTeamColor, getPositionColor, getYearColor }: PlayerTableProps) {
  return (
    <Table>
      <TableHeader className="bg-[#f8f9fa]">
        <TableRow>
          <TableHead className="w-[60px] font-bold">Rank</TableHead>
          <TableHead className="font-bold">Player</TableHead>
          <TableHead className="text-center font-bold">PPG</TableHead>
          <TableHead className="text-center font-bold">REB</TableHead>
          <TableHead className="text-center font-bold">AST</TableHead>
          <TableHead className="text-center font-bold">STL</TableHead>
          <TableHead className="text-center font-bold">BLK</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {players.map((player, index) => (
          <TableRow key={player.name} className="hover:bg-gray-50 cursor-pointer">
            <TableCell className="font-medium">
              <div className="w-6 h-6 rounded-full bg-[#0a2240] text-white flex items-center justify-center text-xs">
                {index + 1}
              </div>
            </TableCell>
            <TableCell>
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className={`${getTeamColor(player.school)} text-white`}>
                    {player.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold">{player.name}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary" className={`${getPositionColor(player.position)} text-white`}>
                      {player.position}
                    </Badge>
                    <Badge variant="outline" className={getYearColor(player.year)}>
                      {player.year}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{player.school}</span>
                  </div>
                </div>
              </div>
            </TableCell>
            <TableCell className={`text-center ${statHighlight === "pointsPerGame" ? "font-bold text-[#e31837]" : ""}`}>
              {player.pointsPerGame.toFixed(1)}
            </TableCell>
            <TableCell className={`text-center ${statHighlight === "rebounds" ? "font-bold text-[#e31837]" : ""}`}>
              {player.rebounds.toFixed(1)}
            </TableCell>
            <TableCell className={`text-center ${statHighlight === "assists" ? "font-bold text-[#e31837]" : ""}`}>
              {player.assists.toFixed(1)}
            </TableCell>
            <TableCell className="text-center">{player.steals.toFixed(1)}</TableCell>
            <TableCell className="text-center">{player.blocks.toFixed(1)}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

