"use client"

import dynamic from "next/dynamic"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { RosterSearch } from "./roster-search"

// Use dynamic import inside a client component
const TeamsRosters = dynamic(() => import("@/components/teams-roster-wrapper"), { ssr: false })

export function TeamsRosterTab() {
  return (
    <Tabs>
      <TabsContent value="rosters">
        <div className="space-y-6">
          <RosterSearch />
          <TeamsRosters />
        </div>
      </TabsContent>
    </Tabs>
  )
}

