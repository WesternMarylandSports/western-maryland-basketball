"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Award, CheckCircle2, VoteIcon } from "lucide-react"

interface PollOption {
  id: string
  name: string
  teamName: string
  position?: string
  grade?: string
  image?: string
  votes: number
}

interface PollProps {
  id: string
  title: string
  description: string
  options: PollOption[]
  endDate?: string
  className?: string
}

export function Poll({ id, title, description, options: initialOptions, endDate, className }: PollProps) {
  // Retrieve saved votes from localStorage if available
  const [options, setOptions] = useState(() => {
    if (typeof window !== "undefined") {
      const savedPoll = localStorage.getItem(`poll-${id}`)
      return savedPoll ? JSON.parse(savedPoll) : initialOptions
    }
    return initialOptions
  })

  const [hasVoted, setHasVoted] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem(`poll-${id}-voted`) === "true"
    }
    return false
  })

  const [selectedOption, setSelectedOption] = useState<string | null>(null)

  // Save poll state to localStorage when it changes
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem(`poll-${id}`, JSON.stringify(options))
      localStorage.setItem(`poll-${id}-voted`, hasVoted.toString())
    }
  }, [options, hasVoted, id])

  const totalVotes = options.reduce((sum, option) => sum + option.votes, 0)

  // Calculate percentage for each option
  const getPercentage = (votes: number) => {
    if (totalVotes === 0) return 0
    return Math.round((votes / totalVotes) * 100)
  }

  const handleVote = () => {
    if (!selectedOption || hasVoted) return

    setOptions(
      options.map((option) => (option.id === selectedOption ? { ...option, votes: option.votes + 1 } : option)),
    )

    setHasVoted(true)
    setSelectedOption(null)
  }

  // Get team color for the avatar
  const getTeamColor = (teamName: string) => {
    switch (teamName) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 text-[#e31837]" />
          <CardTitle>{title}</CardTitle>
        </div>
        <CardDescription>{description}</CardDescription>
        {endDate && <CardDescription className="text-xs mt-1">Voting ends: {endDate}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {options.map((option) => {
            const percentage = getPercentage(option.votes)

            return (
              <div
                key={option.id}
                className={`relative rounded-lg border p-4 transition-all ${
                  selectedOption === option.id ? "border-primary bg-primary/5" : "hover:border-primary/50"
                } ${hasVoted ? "cursor-default" : "cursor-pointer"}`}
                onClick={() => {
                  if (!hasVoted) setSelectedOption(option.id)
                }}
              >
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 border">
                    {option.image ? (
                      <AvatarImage src={option.image} alt={option.name} />
                    ) : (
                      <AvatarFallback className={getTeamColor(option.teamName)}>
                        {option.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium">{option.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {option.teamName} {option.position && `• ${option.position}`}{" "}
                      {option.grade && `• ${option.grade}`}
                    </div>
                  </div>

                  {hasVoted && (
                    <div className="ml-auto text-right">
                      <div className="font-bold">{percentage}%</div>
                      <div className="text-xs text-muted-foreground">
                        {option.votes} {option.votes === 1 ? "vote" : "votes"}
                      </div>
                    </div>
                  )}

                  {!hasVoted && selectedOption === option.id && (
                    <div className="absolute right-4 top-1/2 -translate-y-1/2">
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    </div>
                  )}
                </div>

                {hasVoted && (
                  <div className="mt-2">
                    <Progress value={percentage} className="h-2" />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </CardContent>

      {!hasVoted && (
        <CardFooter>
          <Button className="w-full gap-2" onClick={handleVote} disabled={!selectedOption}>
            <VoteIcon className="h-4 w-4" />
            Cast Your Vote
          </Button>
        </CardFooter>
      )}

      {hasVoted && (
        <CardFooter className="flex flex-col items-center gap-2">
          <div className="text-sm text-center">
            Thanks for voting! Total votes: <span className="font-bold">{totalVotes}</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setHasVoted(false)
              setSelectedOption(null)
            }}
          >
            Vote Again
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

