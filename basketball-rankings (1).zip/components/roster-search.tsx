"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { teamsData } from "@/data/teams-data"

type SearchResult = {
  type: "player" | "team"
  playerName?: string
  team: string
  position?: string
  number?: string
  grade?: string
  height?: string
  mascot?: string
}

export function RosterSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    setIsSearching(true)

    // Create searchable array with both players and teams
    const searchItems: SearchResult[] = []

    // Add teams
    teamsData.forEach((team) => {
      searchItems.push({
        type: "team",
        team: team.name,
        mascot: team.mascot,
      })

      // Add players
      team.players.forEach((player) => {
        searchItems.push({
          type: "player",
          playerName: player.name,
          team: team.name,
          position: player.position,
          number: player.number,
          grade: player.grade,
          height: player.height,
        })
      })
    })

    // Filter based on search query
    const query = searchQuery.toLowerCase()
    const results = searchItems.filter((item) => {
      if (item.type === "team") {
        return item.team.toLowerCase().includes(query) || (item.mascot && item.mascot.toLowerCase().includes(query))
      } else {
        return (
          item.playerName?.toLowerCase().includes(query) ||
          item.team.toLowerCase().includes(query) ||
          item.position?.toLowerCase().includes(query) ||
          item.number?.includes(query) ||
          item.grade?.toLowerCase().includes(query)
        )
      }
    })

    setSearchResults(results)
    setIsSearching(false)
  }

  return (
    <div className="w-full">
      <div className="flex gap-2 mb-4">
        <Input
          placeholder="Search players or teams..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          className="flex-1"
        />
        <Button onClick={handleSearch} disabled={isSearching}>
          <Search className="h-4 w-4 mr-2" />
          {isSearching ? "Searching..." : "Search"}
        </Button>
      </div>

      {searchResults.length > 0 && (
        <Card className="mt-4">
          <CardContent className="p-4">
            <h3 className="text-lg font-bold mb-2">Search Results ({searchResults.length})</h3>

            {/* Team Results */}
            {searchResults.some((result) => result.type === "team") && (
              <div className="mb-4">
                <h4 className="font-semibold mb-2">Teams</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {searchResults
                    .filter((result) => result.type === "team")
                    .map((result, index) => (
                      <div key={`team-${index}`} className="p-2 border rounded hover:bg-gray-50">
                        <span className="font-medium">{result.team}</span>
                        {result.mascot && <span className="text-gray-500 ml-1">{result.mascot}</span>}
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* Player Results */}
            {searchResults.some((result) => result.type === "player") && (
              <div>
                <h4 className="font-semibold mb-2">Players</h4>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="text-left p-2 border">Player</th>
                        <th className="text-left p-2 border">Team</th>
                        <th className="text-left p-2 border">Position</th>
                        <th className="text-left p-2 border">Number</th>
                        <th className="text-left p-2 border">Grade</th>
                        <th className="text-left p-2 border">Height</th>
                      </tr>
                    </thead>
                    <tbody>
                      {searchResults
                        .filter((result) => result.type === "player")
                        .map((result, index) => (
                          <tr key={`player-${index}`} className="hover:bg-gray-50">
                            <td className="p-2 border">{result.playerName}</td>
                            <td className="p-2 border">{result.team}</td>
                            <td className="p-2 border">{result.position}</td>
                            <td className="p-2 border">{result.number}</td>
                            <td className="p-2 border">{result.grade}</td>
                            <td className="p-2 border">{result.height}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {searchQuery && searchResults.length === 0 && !isSearching && (
        <div className="text-center p-4 bg-gray-50 rounded-md mt-4">
          <p>No results found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
  )
}

