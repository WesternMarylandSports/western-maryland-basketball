"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Camera, FileVideo, ImageIcon, Upload, X } from "lucide-react"
import { teamsData } from "@/data/teams-data"
import { playersData } from "@/data/players-data"
import Image from "next/image"

type MediaType = "photo" | "video" | "highlight"
type MediaItem = {
  id: string
  type: MediaType
  title: string
  description: string
  file: File
  preview: string
  teamId?: string
  playerId?: string
  uploadDate: Date
}

export function MediaUpload() {
  const [mediaType, setMediaType] = useState<MediaType>("photo")
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [team, setTeam] = useState("")
  const [player, setPlayer] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadedMedia, setUploadedMedia] = useState<MediaItem[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Filter players based on selected team
  const filteredPlayers = team ? playersData.filter((p) => p.team === team) : []

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]
      setFile(selectedFile)

      // Create preview URL
      const fileUrl = URL.createObjectURL(selectedFile)
      setPreview(fileUrl)
    }
  }

  const handleRemoveFile = () => {
    setFile(null)
    setPreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!file) {
      toast({
        title: "Error",
        description: "Please select a file to upload",
        variant: "destructive",
      })
      return
    }

    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a title",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    // Simulate upload delay
    setTimeout(() => {
      const newMedia: MediaItem = {
        id: Date.now().toString(),
        type: mediaType,
        title,
        description,
        file,
        preview: preview!,
        teamId: team || undefined,
        playerId: player || undefined,
        uploadDate: new Date(),
      }

      // Add to uploaded media
      setUploadedMedia((prev) => [newMedia, ...prev])

      // Reset form
      setTitle("")
      setDescription("")
      setFile(null)
      setPreview(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }

      setIsUploading(false)

      toast({
        title: "Success",
        description: "Media uploaded successfully",
      })
    }, 1500)
  }

  const handleDeleteMedia = (id: string) => {
    setUploadedMedia((prev) => prev.filter((item) => item.id !== id))
    toast({
      title: "Deleted",
      description: "Media has been removed",
    })
  }

  return (
    <div className="space-y-8">
      <Toaster />

      <Card>
        <CardHeader>
          <CardTitle>Upload Media</CardTitle>
          <CardDescription>Share photos, videos, and highlights of players and teams</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label>Media Type</Label>
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant={mediaType === "photo" ? "default" : "outline"}
                  onClick={() => setMediaType("photo")}
                  className="flex items-center gap-2"
                >
                  <ImageIcon className="h-4 w-4" />
                  Photo
                </Button>
                <Button
                  type="button"
                  variant={mediaType === "video" ? "default" : "outline"}
                  onClick={() => setMediaType("video")}
                  className="flex items-center gap-2"
                >
                  <FileVideo className="h-4 w-4" />
                  Video
                </Button>
                <Button
                  type="button"
                  variant={mediaType === "highlight" ? "default" : "outline"}
                  onClick={() => setMediaType("highlight")}
                  className="flex items-center gap-2"
                >
                  <Camera className="h-4 w-4" />
                  Highlight Reel
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter a title for your media"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="file">File</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="file"
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept={mediaType === "photo" ? "image/*" : "video/*"}
                    className={preview ? "hidden" : ""}
                  />
                  {preview && (
                    <div className="relative flex-1">
                      <div className="flex items-center gap-2 p-2 border rounded-md">
                        {mediaType === "photo" ? (
                          <div className="relative w-12 h-12">
                            <Image
                              src={preview || "/placeholder.svg"}
                              alt="Preview"
                              fill
                              className="object-cover rounded"
                            />
                          </div>
                        ) : (
                          <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center">
                            <FileVideo className="h-6 w-6 text-gray-500" />
                          </div>
                        )}
                        <div className="flex-1 truncate">
                          <div className="text-sm font-medium truncate">{file?.name}</div>
                          <div className="text-xs text-gray-500">
                            {(file?.size && (file.size / 1024 / 1024).toFixed(2)) || 0} MB
                          </div>
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={handleRemoveFile}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add a description..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="team">Team (Optional)</Label>
                <Select value={team} onValueChange={setTeam}>
                  <SelectTrigger id="team">
                    <SelectValue placeholder="Select a team" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {teamsData.map((team) => (
                      <SelectItem key={team.name} value={team.name}>
                        {team.name} {team.mascot}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="player">Player (Optional)</Label>
                <Select value={player} onValueChange={setPlayer} disabled={!team}>
                  <SelectTrigger id="player">
                    <SelectValue placeholder={team ? "Select a player" : "Select a team first"} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {filteredPlayers.map((player) => (
                      <SelectItem key={player.id} value={player.id}>
                        {player.name} ({player.position})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isUploading || !file}>
              {isUploading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-r-transparent"></div>
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Upload {mediaType === "photo" ? "Photo" : mediaType === "video" ? "Video" : "Highlight"}
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {uploadedMedia.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Uploads</CardTitle>
            <CardDescription>Recently uploaded media ({uploadedMedia.length})</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {uploadedMedia.map((item) => {
                const playerInfo = item.playerId ? playersData.find((p) => p.id === item.playerId) : null

                return (
                  <Card key={item.id} className="overflow-hidden">
                    <div className="aspect-video relative bg-gray-100">
                      {item.type === "photo" ? (
                        <Image
                          src={item.preview || "/placeholder.svg"}
                          alt={item.title}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <FileVideo className="h-12 w-12 text-gray-400" />
                        </div>
                      )}
                    </div>
                    <CardHeader className="p-3">
                      <CardTitle className="text-base">{item.title}</CardTitle>
                      {item.teamId && (
                        <CardDescription className="text-xs">
                          Team: {item.teamId}
                          {playerInfo && ` • Player: ${playerInfo.name}`}
                        </CardDescription>
                      )}
                    </CardHeader>
                    <CardFooter className="p-3 pt-0 flex justify-between">
                      <div className="text-xs text-gray-500">{new Date(item.uploadDate).toLocaleDateString()}</div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteMedia(item.id)}
                        className="h-7 px-2 text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        Delete
                      </Button>
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

