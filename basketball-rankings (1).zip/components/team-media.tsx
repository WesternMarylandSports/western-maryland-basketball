"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { FileVideo, ImageIcon, Upload } from "lucide-react"
import Image from "next/image"
import { MediaUpload } from "./media-upload"

interface TeamMediaProps {
  teamName: string
  teamMascot: string
}

export function TeamMedia({ teamName, teamMascot }: TeamMediaProps) {
  const [activeTab, setActiveTab] = useState("photos")
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false)

  // Sample media for the team
  const teamPhotos = [
    {
      id: "p1",
      title: "Team Photo",
      image: "/placeholder.svg?height=200&width=300&text=Team+Photo",
      date: "February 15, 2025",
    },
    {
      id: "p2",
      title: "Game Action",
      image: "/placeholder.svg?height=200&width=300&text=Game+Action",
      date: "March 5, 2025",
    },
    {
      id: "p3",
      title: "Senior Night",
      image: "/placeholder.svg?height=200&width=300&text=Senior+Night",
      date: "February 20, 2025",
    },
    {
      id: "p4",
      title: "Championship Celebration",
      image: "/placeholder.svg?height=200&width=300&text=Championship",
      date: "March 15, 2025",
    },
  ]

  const teamVideos = [
    {
      id: "v1",
      title: "Game Highlights vs Allegany",
      thumbnail: "/placeholder.svg?height=200&width=300&text=Game+Highlights",
      date: "March 10, 2025",
      duration: "5:45",
    },
    {
      id: "v2",
      title: "Season Highlight Reel",
      thumbnail: "/placeholder.svg?height=200&width=300&text=Season+Highlights",
      date: "March 20, 2025",
      duration: "8:32",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Team Media</h2>
        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload Media
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>
                Upload Media for {teamName} {teamMascot}
              </DialogTitle>
              <DialogDescription>
                Share photos, videos, or highlights of the {teamName} {teamMascot}
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4">
              <MediaUpload />
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="photos" className="flex items-center gap-2">
            <ImageIcon className="h-4 w-4" />
            Photos ({teamPhotos.length})
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex items-center gap-2">
            <FileVideo className="h-4 w-4" />
            Videos ({teamVideos.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="photos" className="mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {teamPhotos.map((photo) => (
              <Card key={photo.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="aspect-video relative">
                  <Image src={photo.image || "/placeholder.svg"} alt={photo.title} fill className="object-cover" />
                </div>
                <CardContent className="p-3">
                  <div className="font-medium text-sm">{photo.title}</div>
                  <div className="text-xs text-gray-500">{photo.date}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="videos" className="mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {teamVideos.map((video) => (
              <Card key={video.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="aspect-video relative">
                  <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center">
                      <div className="w-0 h-0 border-t-6 border-t-transparent border-l-12 border-l-white border-b-6 border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                </div>
                <CardContent className="p-3">
                  <div className="font-medium text-sm">{video.title}</div>
                  <div className="text-xs text-gray-500">{video.date}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

