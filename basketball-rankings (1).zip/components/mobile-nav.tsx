"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, X } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const navItems = [
  { name: "HOME", href: "/" },
  { name: "TEAMS", href: "/teams" },
  { name: "PLAYERS", href: "/players" },
  { name: "SCHEDULES", href: "/schedules" },
  { name: "STANDINGS", href: "/standings" },
  { name: "STATS", href: "/stats" },
  { name: "PHOTOS", href: "/photos" },
  { name: "MEDIA", href: "/media" },
  { name: "NEWS", href: "/news" },
  { name: "POLLS", href: "/polls" },
]

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="text-white md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[80%] max-w-sm p-0">
        <div className="flex flex-col h-full">
          <div className="bg-[#0a2240] p-4 flex justify-between items-center">
            <div className="text-white font-bold text-lg">WMAC HOOPS</div>
            <Button variant="ghost" size="icon" onClick={() => setOpen(false)} className="text-white">
              <X className="h-5 w-5" />
              <span className="sr-only">Close menu</span>
            </Button>
          </div>
          <nav className="flex-1 overflow-auto">
            <ul className="flex flex-col">
              {navItems.map((item) => {
                const isActive = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href)

                return (
                  <li key={item.name} className="border-b border-gray-100 last:border-0">
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center px-4 py-3 hover:bg-gray-50",
                        isActive && "bg-gray-50 text-[#e31837] font-semibold",
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <span>{item.name}</span>
                      {isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#e31837]" />}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>
          <div className="bg-gray-50 p-4 border-t">
            <div className="text-xs text-gray-500 mb-2">FOLLOW US</div>
            <div className="flex space-x-4">
              <a href="#" className="text-sm text-gray-700 hover:text-[#0a2240]">
                Twitter
              </a>
              <a href="#" className="text-sm text-gray-700 hover:text-[#0a2240]">
                Facebook
              </a>
              <a
                href="https://www.instagram.com/westernmarylandsportsnetwork?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
                className="text-sm text-gray-700 hover:text-[#0a2240]"
                target="_blank"
                rel="noopener noreferrer"
              >
                Instagram
              </a>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}

