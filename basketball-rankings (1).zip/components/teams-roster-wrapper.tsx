"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { teamsData } from "@/data/teams-data"

export default function TeamsRosterWrapper() {
  const [activeTeam, setActiveTeam] = useState(teamsData[0].name)

  return (
    <div className="w-full">
      <Tabs defaultValue={activeTeam} onValueChange={setActiveTeam}>
        <div className="overflow-x-auto">
          <TabsList className="inline-flex h-auto p-1 mb-4">
            {teamsData.map((team) => (
              <TabsTrigger
                key={team.name}
                value={team.name}
                className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                {team.name} {team.mascot}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {teamsData.map((team) => (
          <TabsContent key={team.name} value={team.name}>
            <Card>
              <CardHeader style={{ backgroundColor: team.colors.primary, color: "white" }}>
                <CardTitle className="flex items-center justify-between">
                  <span>
                    {team.name} {team.mascot}
                  </span>
                  <span className="text-sm">
                    Colors: {team.colors.primary}, {team.colors.secondary}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="text-left p-2 border">#</th>
                        <th className="text-left p-2 border">Name</th>
                        <th className="text-left p-2 border">Position</th>
                        <th className="text-left p-2 border">Height</th>
                        <th className="text-left p-2 border">Grade</th>
                      </tr>
                    </thead>
                    <tbody>
                      {team.players.map((player, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="p-2 border">{player.number}</td>
                          <td className="p-2 border">{player.name}</td>
                          <td className="p-2 border">{player.position}</td>
                          <td className="p-2 border">{player.height}</td>
                          <td className="p-2 border">{player.grade}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

