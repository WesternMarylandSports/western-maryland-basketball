"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Search, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface SearchResult {
  id: string
  name: string
  type: "player" | "team"
  subtitle?: string
  image?: string
  url: string
}

export function SearchBar() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // Sample data for search results
  const searchData: SearchResult[] = [
    // Teams
    {
      id: "fort-hill",
      name: "Fort Hill",
      type: "team",
      subtitle: "Sentinels",
      url: "/teams#fort-hill",
    },
    {
      id: "allegany",
      name: "Allegany",
      type: "team",
      subtitle: "Campers",
      url: "/teams#allegany",
    },
    {
      id: "southern-garrett",
      name: "Southern Garrett",
      type: "team",
      subtitle: "Rams",
      url: "/teams#southern-garrett",
    },
    {
      id: "mountain-ridge",
      name: "Mountain Ridge",
      type: "team",
      subtitle: "Miners",
      url: "/teams#mountain-ridge",
    },
    {
      id: "northern-garrett",
      name: "Northern Garrett",
      type: "team",
      subtitle: "Huskies",
      url: "/teams#northern-garrett",
    },
    {
      id: "bishop-walsh",
      name: "Bishop Walsh",
      type: "team",
      subtitle: "Spartans",
      url: "/teams#bishop-walsh",
    },

    // Players
    {
      id: "chris-manhertz",
      name: "Chris Manhertz",
      type: "player",
      subtitle: "Allegany • PG • Junior",
      url: "/players#chris-manhertz",
    },
    {
      id: "tyrell-washington",
      name: "Tyrell Washington",
      type: "player",
      subtitle: "Allegany • PG • Junior",
      url: "/players#tyrell-washington",
    },
    {
      id: "brandon-miller",
      name: "Brandon Miller",
      type: "player",
      subtitle: "Southern Garrett • SF • Senior",
      url: "/players#brandon-miller",
    },
    {
      id: "jamal-thompson",
      name: "Jamal Thompson",
      type: "player",
      subtitle: "Mountain Ridge • SG • Senior",
      url: "/players#jamal-thompson",
    },
    {
      id: "darius-williams",
      name: "Darius Williams",
      type: "player",
      subtitle: "Bishop Walsh • PF • Junior",
      url: "/players#darius-williams",
    },
    {
      id: "michael-carter",
      name: "Michael Carter",
      type: "player",
      subtitle: "Northern Garrett • C • Senior",
      url: "/players#michael-carter",
    },
    {
      id: "marcus-johnson",
      name: "Marcus Johnson",
      type: "player",
      subtitle: "Fort Hill • SG • Senior",
      url: "/players#marcus-johnson",
    },
  ]

  // Handle search input change
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setQuery(value)

    if (value.length > 1) {
      setIsSearching(true)
      // Filter search results based on query
      const filtered = searchData.filter(
        (item) =>
          item.name.toLowerCase().includes(value.toLowerCase()) ||
          (item.subtitle && item.subtitle.toLowerCase().includes(value.toLowerCase())),
      )
      setResults(filtered)
      setShowResults(true)
    } else {
      setResults([])
      setShowResults(false)
    }
  }

  // Handle search submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.length > 1) {
      router.push(`/search?q=${encodeURIComponent(query)}`)
      setShowResults(false)
    }
  }

  // Clear search
  const clearSearch = () => {
    setQuery("")
    setResults([])
    setShowResults(false)
  }

  // Close results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Get team color for avatar
  const getTeamColor = (team: string) => {
    switch (team) {
      case "Fort Hill":
        return "bg-red-600"
      case "Mountain Ridge":
        return "bg-yellow-600"
      case "Southern Garrett":
        return "bg-green-600"
      case "Allegany":
        return "bg-blue-600"
      case "Northern Garrett":
        return "bg-blue-800"
      case "Bishop Walsh":
        return "bg-purple-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="relative" ref={searchRef}>
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            type="search"
            placeholder="Search players, teams..."
            className="pl-10 pr-10 w-full"
            value={query}
            onChange={handleSearch}
            onFocus={() => {
              if (query.length > 1) setShowResults(true)
            }}
          />
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-0 hover:bg-transparent"
              onClick={clearSearch}
            >
              <X className="h-4 w-4 text-gray-400" />
              <span className="sr-only">Clear search</span>
            </Button>
          )}
        </div>
      </form>

      {/* Search Results Dropdown */}
      {showResults && (
        <div className="absolute top-full left-0 right-0 z-50 mt-1 max-h-[70vh] overflow-auto rounded-md border bg-white shadow-lg">
          <div className="p-2">
            {isSearching && results.length === 0 ? (
              <div className="p-4 text-center text-sm text-gray-500">No results found for "{query}"</div>
            ) : (
              <>
                {results.length > 0 && (
                  <div className="mb-2 px-2 text-xs font-semibold text-gray-500">{results.length} results</div>
                )}

                {/* Team Results */}
                {results.filter((r) => r.type === "team").length > 0 && (
                  <div className="mb-2">
                    <div className="mb-1 px-2 text-xs font-semibold text-gray-500">Teams</div>
                    {results
                      .filter((r) => r.type === "team")
                      .map((result) => (
                        <Link
                          key={result.id}
                          href={result.url}
                          onClick={() => setShowResults(false)}
                          className="flex items-center gap-3 rounded-md px-2 py-2 hover:bg-gray-100"
                        >
                          <div
                            className={`w-8 h-8 rounded-full ${getTeamColor(result.name)} text-white flex items-center justify-center font-bold text-xs`}
                          >
                            {result.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </div>
                          <div>
                            <div className="font-medium">{result.name}</div>
                            <div className="text-xs text-gray-500">{result.subtitle}</div>
                          </div>
                          <Badge variant="outline" className="ml-auto">
                            Team
                          </Badge>
                        </Link>
                      ))}
                  </div>
                )}

                {/* Player Results */}
                {results.filter((r) => r.type === "player").length > 0 && (
                  <div>
                    <div className="mb-1 px-2 text-xs font-semibold text-gray-500">Players</div>
                    {results
                      .filter((r) => r.type === "player")
                      .map((result) => {
                        const teamName = result.subtitle?.split("•")[0].trim() || ""
                        return (
                          <Link
                            key={result.id}
                            href={result.url}
                            onClick={() => setShowResults(false)}
                            className="flex items-center gap-3 rounded-md px-2 py-2 hover:bg-gray-100"
                          >
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className={`${getTeamColor(teamName)} text-white`}>
                                {result.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{result.name}</div>
                              <div className="text-xs text-gray-500">{result.subtitle}</div>
                            </div>
                            <Badge variant="outline" className="ml-auto">
                              Player
                            </Badge>
                          </Link>
                        )
                      })}
                  </div>
                )}

                {/* View all results link */}
                {results.length > 0 && (
                  <div className="mt-2 border-t pt-2">
                    <Link
                      href={`/search?q=${encodeURIComponent(query)}`}
                      onClick={() => setShowResults(false)}
                      className="block rounded-md px-2 py-2 text-center text-sm font-medium text-[#e31837] hover:bg-gray-100"
                    >
                      View all results
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

